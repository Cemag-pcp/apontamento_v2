// parcial = true: grava o que foi medido sem finalizar (dispensa o campo "Inspeção 100%")
function enviarDadosInspecao(parcial = false) {
    if (!validarFormulario({ parcial })) {
        return;
    }

    const buttonSalvarInspecao = document.getElementById('saveInspection');
    const buttonSalvarParcial = document.getElementById('savePartialInspection');
    const buttonClicado = parcial ? buttonSalvarParcial : buttonSalvarInspecao;
    const textoOriginal = buttonClicado.innerHTML;
    buttonSalvarInspecao.disabled = true;
    buttonSalvarParcial.disabled = true;
    buttonClicado.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>';

    const formData = new FormData();

    formData.append('salvar_parcial', parcial ? 'true' : 'false');
    formData.append('inspecao_id', document.getElementById('id-inspecao').value);
    formData.append('dataInspecao', document.getElementById('dataInspecao').value);
    formData.append('pecasProduzidas', document.getElementById('pecasProduzidas').value);
    formData.append('inspetor', document.getElementById('inspetor').value);
    formData.append('inspecao_total', document.getElementById('inspecao_total').value);

    const inspecoesAtivas = [];
    document.querySelectorAll('.inspection-checkbox:checked').forEach(checkbox => {
        const tipo = checkbox.id.replace('checkbox-inspecao-', '');
        inspecoesAtivas.push(tipo);
    });
    formData.append('inspecoes_ativas', JSON.stringify(inspecoesAtivas));

    const causasPecaMorta = [];
    document.querySelectorAll('.causas-morta-container .causa-checkbox:checked').forEach(checkbox => {
        causasPecaMorta.push(checkbox.value);
    });
    formData.append('causasPecaMorta', JSON.stringify(causasPecaMorta));

    const qtdProduzida = parseInt(document.getElementById('pecasProduzidas').value, 10) || 1;
    const qtdLinhasSelecionadas = parseInt(document.getElementById('measurementRowsCount')?.value, 10) || 1;
    const qtdLinhas = Math.max(1, Math.min(qtdProduzida, qtdLinhasSelecionadas));

    inspecoesAtivas.forEach(tipo => {
        const medidasTipo = [];
        const tipoCapitalizado = tipo.charAt(0).toUpperCase() + tipo.slice(1);

        const cabecalhos = [];
        document.querySelectorAll(`#sectionMedicao${tipoCapitalizado} .medida-input`).forEach((input, index) => {
            cabecalhos[index] = input.value.trim();
        });

        for (let linha = 1; linha <= qtdLinhas; linha++) {
            const medida = {};
            let algumCampoPreenchido = false;

            for (let coluna = 1; coluna <= 8; coluna++) {
                const nomeMedida = cabecalhos[coluna - 1];
                const valorInput = document.querySelector(`input[name="${tipo}_valor${linha}_${coluna}"]`);
                const valor = valorInput ? valorInput.value.trim() : '';

                if (nomeMedida && valor) {
                    medida[`medida${coluna}`] = { nome: nomeMedida, valor: valor };
                    algumCampoPreenchido = true;
                }
            }

            if (algumCampoPreenchido) {
                const conformeCheckbox = document.querySelector(`input[name="${tipo}_conformity${linha}"][value="conforming"]`);
                const conforme = conformeCheckbox ? conformeCheckbox.checked : false;
                medida.conforme = conforme;
                medidasTipo.push(medida);
            }
        }

        if (medidasTipo.length > 0) {
            formData.append(`medidas_${tipo}`, JSON.stringify(medidasTipo));
        }
    });

    const naoConformidades = [];
    document.querySelectorAll('.non-conformity-item').forEach(item => {
        const id = item.id.replace('nonConformityItem', '');
        const causas = [];

        document.querySelectorAll(`#causasContainer${id} .causa-checkbox:checked`).forEach(checkbox => {
            causas.push(checkbox.value);
        });

        const tipo = document.querySelector(`select[name="tipo_nao_conformidade${id}"]`)?.value || '';
        const quantidadeAfetada = document.getElementById(`quantidadeAfetada${id}`).value;
        const destino = document.getElementById(`destino${id}`).value;

        if (tipo || quantidadeAfetada || destino || causas.length > 0) {
            const naoConformidade = {
                id: id,
                tipo: tipo,
                quantidadeAfetada: quantidadeAfetada,
                destino: destino,
                causas: causas
            };

            const fotoInput = document.getElementById(`fotoNaoConformidade${id}`);
            if (fotoInput && fotoInput.files.length > 0) {
                for (let i = 0; i < fotoInput.files.length; i++) {
                    formData.append(`nc_files_${id}`, fotoInput.files[i]);
                }
            }

            naoConformidades.push(naoConformidade);
        }
    });

    if (naoConformidades.length > 0) {
        formData.append('naoConformidades', JSON.stringify(naoConformidades));
    }

    fetch('/inspecao/api/envio-inspecao-serra-usinagem/', {
        method: 'POST',
        headers: {
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        },
        body: formData
    })
        .then(response => response.json().then(data => {
            if (!response.ok) throw new Error(data.error || data.message || `Erro HTTP! Status: ${response.status}`);
            return data;
        }))
        .then(data => {
            const progresso = `${data.amostras_feitas}/${data.amostras_exigidas} amostras`;
            if (data.inspecao_finalizada) {
                Toast.fire({ icon: 'success', title: 'Inspeção finalizada com sucesso!' });
            } else if (parcial) {
                Toast.fire({ icon: 'info', title: `Inspeção salva parcialmente (${progresso}).` });
            } else {
                Toast.fire({
                    icon: 'warning',
                    title: `Inspeção salva como parcial: amostras insuficientes (${progresso}).`
                });
            }

            // Listas da tela de inspeção (não existem no apontamento)
            if (typeof buscarItensInspecao === 'function') buscarItensInspecao(1);
            if (typeof buscarItensReinspecao === 'function') buscarItensReinspecao(1);
            if (typeof buscarItensInspecionados === 'function') buscarItensInspecionados(1);

            const idInspecaoEnviada = document.getElementById('id-inspecao').value;
            const modal = bootstrap.Modal.getInstance(document.getElementById('inspectionModal'));
            if (modal) modal.hide();

            // Avisa quem abriu o modal (ex.: apontamento da serra/usinagem)
            document.dispatchEvent(new CustomEvent('inspecao-serra-usinagem:enviada', {
                detail: {
                    id: idInspecaoEnviada,
                    finalizada: !!data.inspecao_finalizada,
                    amostras_feitas: data.amostras_feitas,
                    amostras_exigidas: data.amostras_exigidas,
                }
            }));
        })
        .catch(error => {
            Toast.fire({
                icon: 'error',
                title: error.message
            });
            console.error('Erro:', error);
        })
        .finally(() => {
            buttonSalvarInspecao.disabled = false;
            buttonSalvarParcial.disabled = false;
            buttonClicado.innerHTML = textoOriginal;
        });
}

document.getElementById('saveInspection').addEventListener('click', () => enviarDadosInspecao(false));
document.getElementById('savePartialInspection').addEventListener('click', () => enviarDadosInspecao(true));
