document.getElementById("form-inspecao").addEventListener("submit", function (event) {
    event.preventDefault();

    const modal = document.getElementById('modal-inspecionar-montagem');
    const modalInstance = bootstrap.Modal.getInstance(modal); // Obter a instância existente
    let buttonInspecionarMontagem = document.getElementById("submit-inspecionar-montagem");
    buttonInspecionarMontagem.disabled = true;
    buttonInspecionarMontagem.querySelector(".spinner-border").style.display = "flex";

    function cancelarEnvio(mensagem) {
        Swal.fire({ icon: 'error', title: mensagem });
        buttonInspecionarMontagem.disabled = false;
        buttonInspecionarMontagem.querySelector(".spinner-border").style.display = "none";
    }

    // Criar um objeto FormData para enviar os arquivos
    const formData = new FormData(this); // Usar o formulário diretamente

    const qtdProduzida = document.getElementById("qtd-produzida-montagem").value;
    const qtdInspecionada = document.getElementById("qtd-inspecao-montagem").value;

    if (qtdInspecionada === "" || parseInt(qtdInspecionada, 10) < 1) {
        cancelarEnvio('Informe a quantidade inspecionada (mínimo 1).');
        return;
    }

    if (parseFloat(qtdInspecionada) > parseFloat(qtdProduzida)) {
        cancelarEnvio('Quantidade Inspecionada não pode ser maior que a quantidade Produzida');
        return;
    }

    const cardsUnidades = document.querySelectorAll("#unidades-checklist-montagem .unidade-checklist-card");
    const totalCausas = CAUSAS_MONTAGEM.length;

    if (cardsUnidades.length !== parseInt(qtdInspecionada, 10)) {
        cancelarEnvio('Erro ao montar o checklist das unidades. Reabra o modal e tente novamente.');
        return;
    }

    const existeUnidadeIncompleta = Array.from(cardsUnidades).some((card) => {
        const respondidos = card.querySelectorAll('.causa-status-ok:checked, .causa-status-nok:checked').length;
        return respondidos < totalCausas;
    });

    if (existeUnidadeIncompleta) {
        cancelarEnvio('Complete o checklist de todas as unidades inspecionadas antes de enviar.');
        return;
    }

    const semFoto = validarImagensNaoConformidadeMontagem(document.getElementById("unidades-checklist-montagem"));
    if (semFoto.length > 0) {
        Swal.fire({
            icon: 'error',
            title: 'Foto obrigatória na não conformidade',
            html: 'Anexe ao menos uma foto em:<br>' + semFoto.join('<br>'),
        });
        buttonInspecionarMontagem.disabled = false;
        buttonInspecionarMontagem.querySelector(".spinner-border").style.display = "none";
        return;
    }

    // Agrega as causas marcadas como "Ñ OK" em todas as unidades: cada
    // causa vira um "bloco" (mesmo formato que o backend ja espera via
    // request.POST.getlist(f"causas_{i}")), somando quantas unidades
    // falharam por aquela causa e juntando as imagens de todas elas.
    const causasAgregadas = new Map();
    document.querySelectorAll("#unidades-checklist-montagem .unidade-checklist-card .causa-status-nok:checked").forEach((radio) => {
        const causaId = radio.getAttribute("data-causa-id");
        const item = radio.closest(".checklist-causa-item");
        const imagensInput = item.querySelector(".causa-imagens");

        if (!causasAgregadas.has(causaId)) {
            causasAgregadas.set(causaId, { quantidade: 0, imagens: [] });
        }
        const entrada = causasAgregadas.get(causaId);
        entrada.quantidade += 1;
        entrada.imagens.push(...Array.from(imagensInput.files));
    });

    let totalBlocos = 0;
    causasAgregadas.forEach((entrada, causaId) => {
        totalBlocos += 1;
        formData.append(`causas_${totalBlocos}`, causaId);
        formData.append(`quantidade_${totalBlocos}`, entrada.quantidade);
        entrada.imagens.forEach((file) => {
            formData.append(`imagens_${totalBlocos}`, file);
        });
    });

    formData.append("quantidade-total-causas", totalBlocos);
    // Campos desabilitados (conformidade/nao-conformidade sao calculados a
    // partir do checklist) nao entram automaticamente no FormData.
    formData.append("conformidade-inspecao-montagem", document.getElementById("conformidade-inspecao-montagem").value);
    formData.append("nao-conformidade-inspecao-montagem", document.getElementById("nao-conformidade-inspecao-montagem").value);

    // Enviar os dados para o backend
    fetch("/inspecao/api/envio-inspecao-montagem/", {
        method: "POST",
        headers: {
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value,
        },
        body: formData, // Usar FormData em vez de JSON
    })
    .then(response => {
        return response.json().then(data => {
            if (!response.ok) {
                throw new Error(data.error || `Erro na requisição HTTP. Status: ${response.status}`);
            }
            return data;
        });
    })
    .then(data => {
        if (modalInstance) {
            modalInstance.hide();
        }
        const Toast = Swal.mixin({
            toast: true,
            position: "bottom-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.onmouseenter = Swal.stopTimer;
              toast.onmouseleave = Swal.resumeTimer;
            }
          });
          Toast.fire({
            icon: "success",
            title: "Inspeção realizada com sucesso"
          });
        buscarItensInspecao(1);
        buscarItensReinspecao(1);
        buscarItensInspecionados(1);
    })
    .catch(error => {
        console.error(error);
        Swal.fire({
            icon: 'error',
            title: 'Erro no envio da inspeção',
            text: error, // Exibe a mensagem do backend corretamente
        });
    })
    .finally(() => {
        buttonInspecionarMontagem.disabled = false;
        buttonInspecionarMontagem.querySelector(".spinner-border").style.display = "none";
    });
});
