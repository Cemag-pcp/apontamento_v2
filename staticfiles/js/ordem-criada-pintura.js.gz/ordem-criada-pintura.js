
const typeTemplate = document.getElementById("type_template").value;
let camboesEmProcessoMap = new Map();
let itensDisponiveisCambao = [];
let edicaoCambaoAtual = null;
let carregandoEdicaoCambao = false;

export const loadOrdens = (container, filtros = {}) => {
    let isLoading = false; // Flag para evitar chamadas duplicadas

    console.log(typeTemplate);
    
    return new Promise((resolve, reject) => {
        if (isLoading) return resolve({ ordens: [] });
        isLoading = true;
        document.getElementById('data-entrega-info').textContent = '[carregando...]';

        fetch(`/pintura/api/ordens-criadas/?type_template=${typeTemplate}&data_carga=${filtros.data_carga}&cor=${filtros.cor || ''}&conjunto=${filtros.conjunto || ''}&data-programada=${filtros.data_programada || ''}`)
            .then(response => response.json())
            .then(data => {
                const ordens = data.ordens;
                container.innerHTML = ""; // Limpa antes de inserir novas ordens

                document.getElementById('data-entrega-info').textContent = data.data_programacao;
                document.getElementById('filtro-data-carga').value = data.data_carga;

                if (ordens.length > 0) {
                    // Criar cabeçalho da tabela
                    const tableWrapper = document.createElement("div");
                    tableWrapper.classList.add("table-container");
        
                    const table = document.createElement('table');
                    table.classList.add('table', 'table-bordered', 'table-striped', 'header-fixed');

                    table.innerHTML = `
                        <thead class="table-light">
                            <tr>
                                <th style="width: 10%;">Ch. Peça</th>
                                <th style="width: 15%;">Código Peça</th>
                                <th style="width: 15%;">Data Programação</th>
                                <th style="width: 10%;">Cor</th>
                                <th style="width: 10%;">Qtd. Disponível</th>
                                <th style="width: 5%; text-align: center;">
                                    <input type="checkbox" id="select-all">
                                </th>
                                <th style="width: 10%;">Qtd. a Pendurar</th>
                            </tr>
                        </thead>
                        <tbody id="tabela-ordens-corpo"></tbody>
                    `;

                    tableWrapper.appendChild(table);
                    container.appendChild(tableWrapper);
    
                    // container.appendChild(table);
                    const tabelaCorpo = document.getElementById('tabela-ordens-corpo');

                    ordens.forEach(ordem => {
                        const linha = document.createElement('tr');
                        linha.dataset.ordemId = ordem.id;
                        linha.dataset.pecaOrdem = ordem.peca_ordem_id;
                        linha.dataset.cor = ordem.cor; // Adiciona a cor da peça para controle

                        linha.innerHTML = `
                            <td>#${ordem.ordem}</td>
                            <td>
                                <a href="https://drive.google.com/drive/u/0/search?q=${pegarCodigoPeca(ordem.peca_codigo)}" 
                                target="_blank" rel="noopener noreferrer">
                                ${ordem.peca_codigo}
                                </a>
                            </td>
                            <td>${ordem.data_programacao}</td>
                            <td>${ordem.cor}</td>
                            <td>${ordem.qt_restante}</td>
                            <td style="text-align: center;">
                                <input type="checkbox" class="ordem-checkbox" data-ordem-id="${ordem.id}" data-cor="${ordem.cor}">
                            </td>
                            <td>
                                <input type="number" class="form-control qt-produzida" min="1" max="${ordem.qt_restante}">
                            </td>
                        `;

                        tabelaCorpo.appendChild(linha);
                    });

                    // Evento para habilitar/desabilitar o botão ao marcar checkboxes e verificar cor e quantidade preenchida
                    const checkboxes = document.querySelectorAll(".ordem-checkbox");
                    

                    checkboxes.forEach(checkbox => {
                        checkbox.addEventListener("change", () => {
                            const selecionados = [...checkboxes].filter(cb => cb.checked);
                            const corSelecionada = selecionados.length > 0 ? selecionados[0].dataset.cor : null;
                            let isValid = true;                        
                            const qtdPendurarMax = checkbox.closest('tr').querySelector('.qt-produzida');

                            selecionados.forEach(cb => {
                                //Preenche o campo de quantidade com o valor máximo
                                const linha = cb.closest('tr');
                                const qtInput = linha.querySelector('.qt-produzida');
                                const maxQtPermitida = parseInt(qtInput.getAttribute("max"), 10);
                                const qtSelecionada = parseInt(qtInput.value, 10);
                                const qtdProduzida = cb.closest('tr').querySelector('.qt-produzida');

                                if (qtSelecionada > maxQtPermitida || (qtSelecionada == 0 || isNaN(qtSelecionada))){  
                                    qtdProduzida.value = maxQtPermitida;
                                }
                    
                                // Verifica se o campo de quantidade foi preenchido corretamente
                                if (qtSelecionada <= 0) {
                                    cb.checked = false; // Desmarca o checkbox inválido
                                    if (selecionados.length == 1) {
                                        isValid = false;
                                    }
                                    

                                    Swal.fire({
                                        icon: "warning",
                                        title: "Quantidade Inválida",
                                        text: "Você precisa preencher a quantidade antes de selecionar esta ordem!",
                                        confirmButtonText: "OK"
                                    });
                                    return;
                                }
                    
                                // ⚠ Verifica se a quantidade ultrapassa o permitido
                                if (qtSelecionada > maxQtPermitida) {
                                    cb.checked = false; // Desmarca o checkbox inválido
                                    if (selecionados.length == 1) {
                                        isValid = false;
                                    }

                                    Swal.fire({
                                        icon: "warning",
                                        title: "Quantidade Excedida",
                                        text: `O valor máximo permitido é ${maxQtPermitida}.`,
                                        confirmButtonText: "OK"
                                    });

                                }

                                if (qtSelecionada > maxQtPermitida || (qtSelecionada == 0 || isNaN(qtSelecionada))){  
                                    qtdProduzida.value = maxQtPermitida;
                                }
                            });
                    
                            // ⚠ Se houver cores diferentes, impede a seleção
                            const coresDiferentes = selecionados.some(cb => cb.dataset.cor !== corSelecionada);
                            if (coresDiferentes) {
                                checkbox.checked = false;
                                if (selecionados.length == 1) {
                                    isValid = false;
                                }
                    
                                Swal.fire({
                                    icon: "warning",
                                    title: "Seleção Inválida",
                                    text: "Todas as peças do cambão devem ter a mesma cor!",
                                    confirmButtonText: "OK"
                                });
                                qtdPendurarMax.value = ''; // Limpa o campo de quantidade
                            }

                            // Habilita o botão apenas se houver seleções válidas
                            if (typeTemplate === 'apontamento') {
                                document.getElementById("btn-criar-cambao").disabled = selecionados.length === 0 || !isValid;
                            }

                            if (typeTemplate === 'programacao') {
                                document.getElementById("btn-criar-programacao").disabled = selecionados.length === 0 || !isValid;
                            }
                            
                        });
                    });

                    // Evento para selecionar todos os checkboxes (somente se todas forem da mesma cor e com quantidade preenchida)
                    document.getElementById("select-all").addEventListener("change", (e) => {
                        // Passo 1: Verificar se as cores do filtro são iguais
                        const isChecked = e.target.checked;
                        if (!isChecked) {
                            checkboxes.forEach(cb => {
                                cb.checked = false;
                                const linha = cb.closest('tr');
                                const qtInput = linha.querySelector('.qt-produzida');
                                qtInput.value = '';
                            });
                            document.getElementById("btn-criar-cambao").disabled = true;
                            return;
                        }
                        const primeiraCor = checkboxes[0]?.dataset.cor;
                        let isValid = true;

                        checkboxes.forEach(cb => {
                            const linha = cb.closest('tr');
                            const qtInput = linha.querySelector('.qt-produzida');
                            const maxQtPermitida = parseInt(qtInput.getAttribute("max"), 10);

                            if (cb.dataset.cor === primeiraCor && isChecked){
                                qtInput.value = maxQtPermitida;
                                cb.checked = isChecked;
                            }else {
                                qtInput.value = '';
                                cb.checked = false;
                                isValid = false;
                            }
                            
                        });

                        if (!isValid) {
                            checkboxes.forEach(cb => {
                                cb.checked = false;
                                const linha = cb.closest('tr');
                                const qtInput = linha.querySelector('.qt-produzida');
                                qtInput.value = '';
                                document.getElementById("btn-criar-cambao").disabled = true;
                            });

                            Swal.fire({
                                icon: "warning",
                                title: "Seleção Inválida",
                                text: "Verifique os filtros garatindo que seja estabelecido apenas uma cor!",
                                confirmButtonText: "OK"
                            });

                            
                        }

                        // Verifica se há checkboxes válidos marcados
                        const algumSelecionado = [...checkboxes].some(cb => cb.checked);
                        document.getElementById("btn-criar-cambao").disabled = !algumSelecionado || !isValid;
                    });

                    // Evento para marcar checkbox ao digitar a quantidade
                    document.querySelectorAll(".qt-produzida").forEach(input => {
                        input.addEventListener("input", () => {
                            const linha = input.closest('tr');
                            const checkbox = linha.querySelector('.ordem-checkbox');
                            const maxQtPermitida = parseInt(input.getAttribute("max"), 10);
                            const qtSelecionada = parseInt(input.value, 10);

                            if (input.value && qtSelecionada > 0 && qtSelecionada <= maxQtPermitida) {
                                checkbox.checked = true;
                            } else {
                                checkbox.checked = false;
                            }

                            // Simula o evento de mudança para atualizar o botão
                            checkbox.dispatchEvent(new Event('change'));
                        });
                    });

                    resolve(data);
                } else {
                    container.innerHTML = '<p class="text-danger">Nenhuma ordem encontrada.</p>';
                    resolve(data);
                }
            })
            .catch(error => {
                console.error('Erro ao buscar ordens:', error);
                container.innerHTML = '<p class="text-danger">Erro ao carregar as ordens.</p>';
                reject(error);
            })
            .finally(() => {
                isLoading = false; // Libera a flag em qualquer caso
            });
    });
};

export function carregarOrdensIniciadas(container, filtros = {}) {
    container.innerHTML = `
    <div class="spinner-border text-dark" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;

    fetch(`api/ordens-iniciadas/?page=1&limit=100&ordem=${filtros.ordem || ''}&peca=${filtros.peca || ''}`)
        .then(response => response.json())
        .then(data => {
            container.innerHTML = ''; // Limpa o container
            data.ordens.forEach(ordem => {

                const card = document.createElement('div');
                card.dataset.ordemId = ordem.id;

                // Defina os botões dinamicamente com base no status
                let botaoAcao = '';

                botaoAcao = `
                    <button class="btn btn-danger btn-sm btn-interromper" title="Interromper">
                        <i class="fa fa-stop"></i>
                    </button>
                    <button class="btn btn-success btn-sm btn-finalizar" title="Finalizar">
                        <i class="fa fa-check"></i>
                    </button>
                    <button class="btn btn-primary btn-sm btn-proximo-processo" title="Passar para o próximo processo">
                        <i class="fa fa-arrow-right"></i>
                    </button>      
                    <button class="btn btn-info btn-sm btn-finalizar-parcial" title="Finalizar parcial">
                        <i class="fa fa-hourglass-half"></i>
                    </button>
                `;

                // Calcula informações consolidadas das peças
                const totalQtdBoa = ordem.pecas.reduce((acc, peca) => acc + (peca.qtd_boa || 0), 0);
                const totalQtdPlanejada = ordem.pecas.reduce((acc, peca) => acc + (peca.qtd_planejada || 0), 0);
                const pecaInfo = ordem.pecas[0]; // Assume que deseja exibir apenas a primeira peça para detalhes

                card.innerHTML = `
                <div class="card shadow-lg border-0 rounded-3 mb-3 position-relative">
                    <!-- Contador fixado no topo direito -->
                    <span class="badge bg-warning text-dark fw-bold px-3 py-2 position-absolute" 
                        id="contador-${ordem.ordem}" 
                        style="top: -10px; right: 0px; font-size: 0.75rem; z-index: 10;">
                        Carregando...
                    </span>
    
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center p-3">
                        <h6 class="card-title mb-0">#${ordem.ordem} - ${ordem.maquina}</h6>
                        <small class="text-white">Planejada: ${totalQtdPlanejada || 0} Realizada: ${totalQtdBoa}</small>
                    </div>
                    <div class="card-body bg-light">
                        <p class="card-text mb-2 small">
                            <strong>Observação:</strong> ${ordem.obs || 'Sem observações'}
                        </p>
                        <p class="card-text mb-0 small">
                            <a href="https://drive.google.com/drive/u/0/search?q=${pecaInfo.codigo}" target="_blank" rel="noopener noreferrer">
                                ${pecaInfo.codigo} - ${pecaInfo.descricao}
                            </a>
                        </p>
                    </div>

                    <div class="card-footer d-flex justify-content-between align-items-center bg-white small" style="border-top: 1px solid #dee2e6;">
                        <div class="d-flex gap-2">
                            ${botaoAcao} <!-- Insere os botões dinâmicos aqui -->
                        </div>
                    </div>
                </div>`;

                const buttonInterromper = card.querySelector('.btn-interromper');
                const buttonFinalizar = card.querySelector('.btn-finalizar');
                const buttonProxProcesso = card.querySelector('.btn-proximo-processo');
                const buttonFinalizarParcial = card.querySelector('.btn-finalizar-parcial')

                // Adiciona evento ao botão "Interromper", se existir
                if (buttonInterromper) {
                    buttonInterromper.addEventListener('click', () => {
                        mostrarModalInterromper(ordem.id, ordem.grupo_maquina);
                    });
                }

                // Adiciona evento ao botão "Finalizar", se existir
                if (buttonFinalizar) {
                    buttonFinalizar.addEventListener('click', () => {
                        atualizarStatusOrdem(ordem.id, ordem.grupo_maquina, 'finalizada');
                    });
                }

                if (buttonProxProcesso) {
                    buttonProxProcesso.addEventListener('click', () => {
                        mostrarModalProxProcesso(ordem.id, ordem.grupo_maquina);
                    });
                }

                if (buttonFinalizarParcial) {
                    buttonFinalizarParcial.addEventListener('click', () => {
                        mostrarModalFinalizarParcial(ordem.id, ordem.grupo_maquina);
                    });
                }

                container.appendChild(card);

                iniciarContador(ordem.ordem, ordem.ultima_atualizacao)

            });
        })
        .catch(error => console.error('Erro ao buscar ordens iniciadas:', error));
};

export function carregarOrdensInterrompidas(container, filtros = {}) {
    container.innerHTML = `
    <div class="spinner-border text-dark" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;

    // Fetch para buscar ordens interrompidas
    fetch(`api/ordens-interrompidas/?page=1&limit=100&ordem=${filtros.ordem || ''}&peca=${filtros.peca || ''}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar as ordens interrompidas.');
            }
            return response.json();
        })
        .then(data => {
            container.innerHTML = ''; // Limpa o container
            console.log(data);
            data.ordens.forEach(ordem => {
                // Cria o card
                const card = document.createElement('div');
                card.dataset.ordemId = ordem.id;
            
                // Cria a lista de peças em formato simplificado
                const pecasHTML = ordem.pecas.map(peca => `
                    <a href="https://drive.google.com/drive/u/0/search?q=${peca.codigo}" target="_blank" rel="noopener noreferrer">
                        ${peca.codigo} - ${peca.descricao}
                    </a>
                `).join('<br>');
            
                // Botões de ação
                const botaoAcao = `
                    <button class="btn btn-warning btn-sm btn-retornar" title="Retornar">
                        <i class="fa fa-undo"></i>
                    </button>
                `;
            
                // Estrutura do card com fonte menor
                card.innerHTML = `
                    <div class="card shadow-lg border-0 rounded-3 mb-3 position-relative">
                        <!-- Contador fixado no topo direito -->
                        <span class="badge bg-warning text-dark fw-bold px-3 py-2 position-absolute" 
                            id="contador-${ordem.ordem}" 
                            style="top: -10px; right: 0px; font-size: 0.75rem; z-index: 10;">
                            Carregando...
                        </span>
    
                        <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center p-3">
                            <h6 class="card-title mb-0">#${ordem.ordem} - ${ordem.maquina}</h6>
                            <small class="text-white">Motivo: ${ordem.motivo_interrupcao || 'Sem motivo'}</small> 
                        </div>
                        <div class="card-body bg-light">
                            <p class="card-text mb-2 small">
                                <strong>Observação:</strong> ${ordem.obs || 'N/A'}
                            </p>
                            <p class="card-text mb-2 small">
                                ${pecasHTML}
                            </p>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center bg-white small" style="border-top: 1px solid #dee2e6;">
                            <div class="d-flex gap-2">
                                ${botaoAcao} <!-- Insere os botões dinâmicos aqui -->
                            </div>
                        </div>
                    </div>`;
            
                // Adiciona eventos aos botões
                const buttonRetornar = card.querySelector('.btn-retornar');
                if (buttonRetornar) {
                    buttonRetornar.addEventListener('click', () => {
                        mostrarModalRetornar(ordem.id, ordem.grupo_maquina, ordem.maquina_id);
                    });
                }
            
                // Adiciona o card ao container
                container.appendChild(card);

                iniciarContador(ordem.ordem, ordem.ultima_atualizacao)

            });
        })
        .catch(error => {
            console.error('Erro ao buscar ordens interrompidas:', error);
            container.innerHTML = '<p class="text-danger">Erro ao carregar ordens interrompidas.</p>';
        });
};

function carregarOrdensAgProProcesso(container, filtros = {}) {
    container.innerHTML = `
    <div class="spinner-border text-dark" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;

    fetch(`api/ordens-ag-prox-proc/?page=1&limit=100&ordem=${filtros.ordem || ''}&peca=${filtros.peca || ''}`)
        .then(response => response.json())
        .then(data => {
            container.innerHTML = ''; // Limpa o container
            data.ordens.forEach(ordem => {

                const card = document.createElement('div');
                card.dataset.ordemId = ordem.id;

                // Defina os botões dinamicamente com base no status
                let botaoAcao = '';

                botaoAcao = `
                    <button class="btn btn-warning btn-sm btn-iniciar-proximo-processo" title="Iniciar próximo processo">
                        <i class="fa fa-play"></i>
                    </button>
                `;

                card.innerHTML = `

                <div class="card shadow-lg border-0 rounded-3 mb-3 position-relative">
                    <!-- Contador fixado no topo direito -->
                    <span class="badge bg-warning text-dark fw-bold px-3 py-2 position-absolute" 
                        id="contador-${ordem.ordem}" 
                        style="top: -10px; right: 0px; font-size: 0.75rem; z-index: 10;">
                        Carregando...
                    </span>

                    <div class="card-header bg-warning text-white d-flex justify-content-between align-items-center p-3">
                        <h6 class="card-title mb-0"><small>#${ordem.ordem} - ${ordem.maquina}</small></h6>
                        <small class="text-white">
                            Planejada: ${ordem.totais.qtd_planejada || 0} 
                            Realizada: ${ordem.totais.qtd_boa || 0} 
                        </small>
                    </div>
                    <div class="card-body bg-light">
                        <p class="card-text mb-2 small">
                            <strong>Observação:</strong> ${ordem.obs || 'Sem observações'}
                        </p>
                        <p class="card-text mb-0 small">
                            <a href="https://drive.google.com/drive/u/0/search?q=${ordem.pecas[0].codigo}" target="_blank" rel="noopener noreferrer">
                                ${ordem.pecas[0].codigo} - ${ordem.pecas[0].descricao}
                            </a>
                        </p>
                    </div>

                    <div class="card-footer d-flex justify-content-between align-items-center bg-white small" style="border-top: 1px solid #dee2e6;">
                        <div class="d-flex gap-2">
                            ${botaoAcao} <!-- Insere os botões dinâmicos aqui -->
                        </div>
                    </div>
                </div>`;

                const buttonProxProcesso = card.querySelector('.btn-iniciar-proximo-processo');

                // Adiciona evento ao botão para iniciar proximo processo
                if (buttonProxProcesso) {
                    buttonProxProcesso.addEventListener('click', () => {
                        mostrarModalIniciarProxProcesso(ordem.id, ordem.grupo_maquina);
                    });
                }

                container.appendChild(card);

                iniciarContador(ordem.ordem, ordem.ultima_atualizacao)

            });
        })
        .catch(error => console.error('Erro ao buscar ordens iniciadas:', error));
}

function getCSRFToken() {
    return document.querySelector('[name=csrfmiddlewaretoken]').value;
}

function atualizarStatusOrdem(ordemId, grupoMaquina, status) {
    switch (status) {
        case 'iniciada':
            mostrarModalIniciar(ordemId, grupoMaquina);
            break;
        case 'interrompida':
            mostrarModalInterromper(ordemId, grupoMaquina);
            break;
        case 'finalizada':
            mostrarModalFinalizar(ordemId, grupoMaquina);
            break;
        case 'agua_prox_proc':
            mostrarModalIniciarProxProcesso(ordemId, grupoMaquina);
            break;

        default:
        alert('Status desconhecido.');
    }
}

// Modal para "Interromper"
function mostrarModalInterromper(ordemId, grupoMaquina) {
    const modal = new bootstrap.Modal(document.getElementById('modalInterromper'));
    const modalTitle = document.getElementById('modalInterromperLabel');
    const formInterromper = document.getElementById('formInterromperOrdemCorte');

    modalTitle.innerHTML = `Interromper Ordem ${ordemId}`;
    modal.show();

    // Remove listeners antigos e adiciona novo
    const clonedForm = formInterromper.cloneNode(true);
    formInterromper.parentNode.replaceChild(clonedForm, formInterromper);

    clonedForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(clonedForm);
        const motivoInterrupcao = formData.get('motivoInterrupcao');

        Swal.fire({
            title: 'Interrompendo...',
            text: 'Por favor, aguarde enquanto a ordem está sendo interrompida.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        fetch(`api/ordens/atualizar-status/`, {
            method: 'PATCH',
            body: JSON.stringify({
                ordem_id: ordemId,
                grupo_maquina: grupoMaquina,
                status: 'interrompida',
                motivo: motivoInterrupcao
            }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken() // Inclui o CSRF Token no cabeçalho
            }
        })
        .then(response => response.json())
        .then(data => {

            Swal.fire({
                icon: 'success',
                title: 'Sucesso',
                text: 'Ordem interrompida com sucesso.',
            });

            modal.hide();

            // Atualiza a interface
            const containerIniciado = document.querySelector('.containerProcesso');
            carregarOrdensIniciadas(containerIniciado);
            
            const containerInterrompido = document.querySelector('.containerInterrompido');
            carregarOrdensInterrompidas(containerInterrompido);

            // Recarrega os dados chamando a função de carregamento
            document.getElementById('ordens-container').innerHTML = '';
            resetarCardsInicial();

            fetchContagemStatusOrdens();
            fetchStatusMaquinas();

        })
        .catch((error) => {
            console.error('Erro:', error);
            alert('Erro ao interromper a ordem.');
        });
    });
}

// Modal para "Iniciar"
function mostrarModalIniciar(ordemId, grupoMaquina) {
    const modal = new bootstrap.Modal(document.getElementById('modalIniciar'));
    const modalTitle = document.getElementById('modalIniciarLabel');

    Swal.fire({
        title: 'Carregando...',
        text: 'Buscando informações das máquinas...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    // Remove event listeners antigos do formulário e adiciona um novo
    const formIniciar = document.getElementById('formIniciarOrdemCorte');
    const clonedForm = formIniciar.cloneNode(true);
    formIniciar.parentNode.replaceChild(clonedForm, formIniciar);

    clonedForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(clonedForm);
        const maquinaName = formData.get('escolhaMaquinaIniciarOrdem');

        Swal.fire({
            title: 'Iniciando Ordem...',
            text: 'Por favor, aguarde.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            },
        });

        fetch(`api/ordens/atualizar-status/`, {
            method: 'PATCH',
            body: JSON.stringify({
                ordem_id: ordemId,
                grupo_maquina: grupoMaquina,
                status: 'iniciada',
                maquina_nome: maquinaName,
            }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken(),
            },
        })
        .then(async (response) => {
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Erro ao iniciar a ordem.');
            }

            return data;
        })
        .then(() => {
            Swal.fire({
                title: 'Sucesso',
                text: 'Ordem iniciada com sucesso.',
            });

            modal.hide();

            const containerIniciado = document.querySelector('.containerProcesso');
            carregarOrdensIniciadas(containerIniciado);

            document.getElementById('ordens-container').innerHTML = '';
            resetarCardsInicial();

            fetchStatusMaquinas();
            fetchContagemStatusOrdens();
        })
        .catch((error) => {
            Swal.fire({
                title: 'Erro',
                text: error.message,
            });
        });
    });
}

// Modal para "Parcial"
function mostrarModalFinalizarParcial(ordemId, grupoMaquina) {
    const modal = new bootstrap.Modal(document.getElementById('modalFinalizarParcial'));
    const modalTitle = document.getElementById('modalFinalizarParcialLabel');
    const formFinalizar = document.getElementById('formFinalizarParcial');

    // Remove event listeners antigos para evitar duplicidade
    const clonedForm = formFinalizar.cloneNode(true);
    formFinalizar.parentNode.replaceChild(clonedForm, formFinalizar);

    // Configura título do modal
    modalTitle.innerHTML = `Finalizar Ordem Parcialmente ${ordemId}`;
    document.getElementById('bodyPecasFinalizarParcial').innerHTML = '<p class="text-center text-muted">Carregando informações...</p>';

    Swal.fire({
        title: 'Carregando...',
        text: 'Buscando informações da ordem...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    // Fetch para buscar informações da ordem
    fetch(`api/ordens-criadas/${ordemId}/${grupoMaquina.toLowerCase()}/pecas/`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar informações da API');
            }
            return response.json();
        })
        .then(data => {
            Swal.close(); // Fecha o SweetAlert de carregamento
            document.getElementById('bodyPecasFinalizarParcial').innerHTML = `
            <div class="row mb-3">
                <div class="col-sm-6">
                    <label for="qtRealizada">Qt. peças boas</label>
                    <input type="number" id="qtRealizada" name="qtRealizada" min=1 class="form-control" required>
                </div>    
                <div class="col-sm-6">
                    <label for="qtMortas">Qt. mortas</label>
                    <input type="number" id="qtMortas" name="qtMortas" min=0 class="form-control">
                </div>    
            </div> 
            `;

            // Exibe o modal
            modal.show();

            // Adiciona o evento de submissão no formulário clonado
            clonedForm.addEventListener('submit', (event) => {
                event.preventDefault();

                // Validação do formulário
                if (!clonedForm.checkValidity()) {
                    clonedForm.reportValidity(); // Exibe mensagens de erro padrão
                    return;
                }

                Swal.fire({
                    title: 'Finalizando...',
                    text: 'Por favor, aguarde...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                const qtRealizada = document.getElementById('qtRealizada').value;
                const qtMortas = document.getElementById('qtMortas').value || 0;
                const operadorFinal = document.getElementById('operadorFinalizarParcial').value;

                // Faz o fetch para finalizar a ordem
                fetch(`api/ordens/atualizar-status/`, {
                    method: 'PATCH',
                    body: JSON.stringify({
                        ordem_id: ordemId,
                        grupo_maquina: grupoMaquina,
                        status: 'finalizada_parcial',
                        qt_realizada: qtRealizada,
                        qt_mortas: qtMortas,
                        operador_final: operadorFinal,
                    }),
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCSRFToken()
                    }
                })
                .then(async (response) => {
                    const data = await response.json();
                    if (!response.ok) {
                        throw new Error(data.error || 'Erro ao finalizar a ordem.');
                    }
                    return data;
                })
                .then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso',
                        text: 'Ordem finalizada com sucesso.',
                    });

                    // Atualiza a interface
                    const containerIniciado = document.querySelector('.containerProcesso');
                    carregarOrdensIniciadas(containerIniciado);

                    // Atualiza a interface
                    const containerInterrompido = document.querySelector('.containerInterrompido');
                    carregarOrdensInterrompidas(containerInterrompido);

                    // Recarrega os dados chamando a função de carregamento
                    document.getElementById('ordens-container').innerHTML = '';
                    resetarCardsInicial();

                    modal.hide();
                })
                .catch((error) => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: error.message,
                    });
                });
            });
        })
        .catch(error => {
            Swal.close(); // Fecha o SweetAlert de carregamento
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Erro ao buscar as informações da ordem.',
            });
        });
}

// Modal para mandar para mandar para "Proximo processo"
function mostrarModalProxProcesso(ordemId, grupoMaquina) {
    const modal = new bootstrap.Modal(document.getElementById('modalProxProcesso'));
    const modalTitle = document.getElementById('modalProxProcessoLabel');

    const colQtdProxProcesso = document.getElementById('colQtdProxProcesso');

    colQtdProxProcesso.style.display = 'block';
    
    const qtdProxProcesso = document.getElementById('qtdProxProcesso');
    qtdProxProcesso.value = '';
    qtdProxProcesso.required = true;
    
    // Exibe SweetAlert de carregamento
    Swal.fire({
        title: 'Carregando...',
        text: 'Buscando informações dos processos...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    // Limpa opções antigas no select
    fetch('/cadastro/api/buscar-processos/?setor=estamparia', {
        method: 'GET',
        headers: {'Content-Type':'application/json'}
    })
    .then(response => response.json())
    .then(
        data => {
            const escolhaProcesso = document.getElementById('escolhaMaquinaProxProcesso');
            const labelModalMaquinaProxProcesso = document.getElementById('labelModalMaquinaProxProcesso');
            escolhaProcesso.innerHTML = `<option value="">------</option>`;

            Swal.close();
            data.processos.forEach((processo) => {
                const option = document.createElement('option');
                option.value = processo.id;
                option.textContent = processo.nome;
                escolhaProcesso.appendChild(option);
            })
            modalTitle.innerHTML = `Passar para próximo processo`;
            labelModalMaquinaProxProcesso.innerHTML = 'Escolha o próximo processo:'
            modal.show();
        }
    ) 

    // Remove listeners antigos e adiciona novo no formulário
    const formIniciar = document.getElementById('formProxProcesso');
    const clonedForm = formIniciar.cloneNode(true);
    formIniciar.parentNode.replaceChild(clonedForm, formIniciar);

    clonedForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(clonedForm);
        const maquinaName = formData.get('escolhaMaquinaProxProcesso');
        const qtdProxProcesso = formData.get('qtdProxProcesso');

        // Exibe SweetAlert de carregamento
        Swal.fire({
            title: 'Mudando processo...',
            text: 'Por favor, aguarde.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            },
        });

        fetch(`api/ordens/atualizar-status/`, {
            method: 'PATCH',
            body: JSON.stringify({
                ordem_id: ordemId,
                grupo_maquina: grupoMaquina,
                status: 'agua_prox_proc',
                maquina_nome: maquinaName,
                qtd_prox_processo: qtdProxProcesso,
            }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken(), // Inclui o CSRF Token no cabeçalho
            },
        })
            .then(async (response) => {
                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error || 'Erro ao iniciar a ordem.');
                }

                return data; // Retorna os dados para o próximo `.then`
            })
            .then(() => {
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso',
                    text: 'Processo alterado com sucesso.',
                });

                modal.hide();

                // Atualiza a interface
                const containerIniciado = document.querySelector('.containerProcesso');
                carregarOrdensIniciadas(containerIniciado);

                // Atualiza a interface
                const containerProxProcesso = document.querySelector('.containerProxProcesso')
                carregarOrdensAgProProcesso(containerProxProcesso);
            
                // Recarrega os dados chamando a função de carregamento
                document.getElementById('ordens-container').innerHTML = '';
                resetarCardsInicial();
            })
            .catch((error) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: error.message,
                });
            });
    });
}

// Modal para para "Iniciar próximo processo"
function mostrarModalIniciarProxProcesso(ordemId, grupoMaquina) {
    const modal = new bootstrap.Modal(document.getElementById('modalProxProcesso'));
    const modalTitle = document.getElementById('modalProxProcessoLabel');

    // const escolhaMaquina = document.getElementById('escolhaMaquinaProxProcesso');
    const qtdProxProcesso = document.getElementById('qtdProxProcesso');
    const colQtdProxProcesso = document.getElementById('colQtdProxProcesso');

    colQtdProxProcesso.style.display = 'none';
    qtdProxProcesso.required = false;

    // Limpa opções antigas no select
    // escolhaMaquina.innerHTML = `<option value="">------</option>`;

    // Exibe SweetAlert de carregamento
    Swal.fire({
        title: 'Carregando...',
        text: 'Buscando informações das máquinas...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Remove listeners antigos e adiciona novo no formulário
    const formIniciar = document.getElementById('formProxProcesso');
    const clonedForm = formIniciar.cloneNode(true);
    formIniciar.parentNode.replaceChild(clonedForm, formIniciar);

    clonedForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(clonedForm);
        const maquinaName = formData.get('escolhaMaquinaProxProcesso');

        // Exibe SweetAlert de carregamento
        Swal.fire({
            title: 'Mudando processo...',
            text: 'Por favor, aguarde.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            },
        });

        fetch(`api/ordens/atualizar-status/`, {
            method: 'PATCH',
            body: JSON.stringify({
                ordem_id: ordemId,
                grupo_maquina: grupoMaquina,
                status: 'iniciada',
                maquina_nome: maquinaName,
            }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken(), // Inclui o CSRF Token no cabeçalho
            },
        })
            .then(async (response) => {
                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error || 'Erro ao iniciar a ordem.');
                }

                return data; // Retorna os dados para o próximo `.then`
            })
            .then(() => {
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso',
                    text: 'Processo alterado com sucesso.',
                });

                modal.hide();

                // Atualiza a interface
                const containerIniciado = document.querySelector('.containerProcesso');
                carregarOrdensIniciadas(containerIniciado);

                // Atualiza a interface
                const containerProxProcesso = document.querySelector('.containerProxProcesso')
                carregarOrdensAgProProcesso(containerProxProcesso);

                // Recarrega os dados chamando a função de carregamento
                document.getElementById('ordens-container').innerHTML = '';
                resetarCardsInicial();

                colQtdProxProcesso.style.display = 'block';
                qtdProxProcesso.required = true;

                fetchStatusMaquinas();
                fetchContagemStatusOrdens();
            
            })
            .catch((error) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: error.message,
                });

                colQtdProxProcesso.style.display = 'block';
                qtdProxProcesso.required = true;

            });
    });
}

// Modal para "Finalizar"
function mostrarModalFinalizar(ordemId, grupoMaquina) {
    const modal = new bootstrap.Modal(document.getElementById('modalFinalizar'));
    const modalTitle = document.getElementById('modalFinalizarLabel');
    const formFinalizar = document.getElementById('formFinalizarOrdemEstamparia');

    // Remove event listeners antigos para evitar duplicidade
    const clonedForm = formFinalizar.cloneNode(true);
    formFinalizar.parentNode.replaceChild(clonedForm, formFinalizar);

    // Configura título do modal
    modalTitle.innerHTML = `Finalizar Ordem ${ordemId}`;
    document.getElementById('bodyPecasFinalizar').innerHTML = '<p class="text-center text-muted">Carregando informações...</p>';

    Swal.fire({
        title: 'Carregando...',
        text: 'Buscando informações da ordem...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    // Fetch para buscar informações da ordem
    fetch(`api/ordens-criadas/${ordemId}/${grupoMaquina.toLowerCase()}/pecas/`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao buscar informações da API');
            }
            return response.json();
        })
        .then(data => {
            Swal.close(); // Fecha o SweetAlert de carregamento
            document.getElementById('bodyPecasFinalizar').innerHTML = `
            <div class="row mb-3">
                <div class="col-sm-6">
                    <label for="qtRealizada">Qt. peças boas</label>
                    <input type="number" id="qtRealizada" name="qtRealizada" min=1 class="form-control" required>
                </div>    
                <div class="col-sm-6">
                    <label for="qtMortas">Qt. mortas</label>
                    <input type="number" id="qtMortas" name="qtMortas" min=0 class="form-control">
                </div>    
            </div> 
            `;
            
            document.getElementById('obsFinalizar').value = '';

            // Exibe o modal
            modal.show();

            // Adiciona o evento de submissão no formulário clonado
            clonedForm.addEventListener('submit', (event) => {
                event.preventDefault();

                // Validação do formulário
                if (!clonedForm.checkValidity()) {
                    clonedForm.reportValidity(); // Exibe mensagens de erro padrão
                    return;
                }

                Swal.fire({
                    title: 'Finalizando...',
                    text: 'Por favor, aguarde...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                const qtRealizada = document.getElementById('qtRealizada').value;
                const qtMortas = document.getElementById('qtMortas').value || 0;
                const operadorFinal = document.getElementById('operadorFinalizar').value;
                const obsFinalizar = document.getElementById('obsFinalizar').value;

                // Faz o fetch para finalizar a ordem
                fetch(`api/ordens/atualizar-status/`, {
                    method: 'PATCH',
                    body: JSON.stringify({
                        ordem_id: ordemId,
                        grupo_maquina: grupoMaquina,
                        status: 'finalizada',
                        qt_realizada: qtRealizada,
                        qt_mortas: qtMortas,
                        operador_final: operadorFinal,
                        obs_finalizar: obsFinalizar
                    }),
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCSRFToken()
                    }
                })
                .then(async (response) => {
                    const data = await response.json();
                    if (!response.ok) {
                        throw new Error(data.error || 'Erro ao finalizar a ordem.');
                    }
                    return data;
                })
                .then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso',
                        text: 'Ordem finalizada com sucesso.',
                    });

                    // Atualiza a interface
                    const containerIniciado = document.querySelector('.containerProcesso');
                    carregarOrdensIniciadas(containerIniciado);

                    // Recarrega os dados chamando a função de carregamento
                    document.getElementById('ordens-container').innerHTML = '';
                    resetarCardsInicial();

                    modal.hide();

                    fetchContagemStatusOrdens();
                    fetchStatusMaquinas();
                    fetchUltimasPecasProduzidas();
        
                })
                .catch((error) => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: error.message,
                    });
                });
            });
        })
        .catch(error => {
            Swal.close(); // Fecha o SweetAlert de carregamento
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Erro ao buscar as informações da ordem.',
            });
        });
}

// Modal para "Retornar"
function mostrarModalRetornar(ordemId, grupoMaquina, maquina) {

    // const maquinaTratada = maquina.toLowerCase().replace(" ","_");

    const modal = new bootstrap.Modal(document.getElementById('modalRetornar'));
    const modalTitle = document.getElementById('modalRetornarLabel');
    const formRetornar = document.getElementById('formRetornarProducao');

    modalTitle.innerHTML = `Retornar Ordem`;
    modal.show();

    // Remove listeners antigos e adiciona novo
    const clonedForm = formRetornar.cloneNode(true);
    formRetornar.parentNode.replaceChild(clonedForm, formRetornar);

    clonedForm.addEventListener('submit', (event) => {
        event.preventDefault();

        Swal.fire({
            title: 'Retornando Ordem...',
            text: 'Por favor, aguarde.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        const formData = new FormData(clonedForm);

        fetch(`api/ordens/atualizar-status/`, {
            method: 'PATCH',
            body: JSON.stringify({
                ordem_id: ordemId,
                grupo_maquina: grupoMaquina,
                status: 'iniciada',
                maquina_nome: maquina,

            }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken() // Inclui o CSRF Token no cabeçalho
            }
        })
        .then(async (response) => {
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Erro ao retornar a ordem.');
            }

            return data; // Retorna os dados para o próximo `.then`
        })
        .then((data) => {
            Swal.fire({
                icon: 'success',
                title: 'Sucesso',
                text: 'Ordem retornada com sucesso.',
            });

            modal.hide();

            // Atualiza a interface
            const containerIniciado = document.querySelector('.containerProcesso');
            carregarOrdensIniciadas(containerIniciado);

            const containerInterrompido = document.querySelector('.containerInterrompido');
            carregarOrdensInterrompidas(containerInterrompido);

            // Recarrega os dados chamando a função de carregamento
            document.getElementById('ordens-container').innerHTML = '';
            resetarCardsInicial();

            fetchContagemStatusOrdens();
            fetchStatusMaquinas();

        })
        .catch((error) => {
            console.error('Erro:', error);
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: error.message,
            });
        });
    });
}

// Modal para "Excluir"
function mostrarModalExcluir(ordemId, setor) {
    const modal = new bootstrap.Modal(document.getElementById('modalExcluir'));
    const modalTitle = document.getElementById('modalExcluirLabel');
    const formExcluir = document.getElementById('formExcluir');

    modalTitle.innerHTML = `Excluir Ordem ${ordemId}`;
    modal.show();

    // Remove listeners antigos e adiciona novo
    const clonedForm = formExcluir.cloneNode(true);
    formExcluir.parentNode.replaceChild(clonedForm, formExcluir);

    clonedForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(clonedForm);
        const motivoExclusao = formData.get('motivoExclusao');

        Swal.fire({
            title: 'Excluindo...',
            text: 'Por favor, aguarde enquanto a ordem está sendo excluída.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        fetch(`/core/api/excluir-ordem/`, {
            method: 'POST',
            body: JSON.stringify({
                ordem_id: ordemId,
                setor: setor,
                motivo: motivoExclusao
            }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken() // Inclui o CSRF Token no cabeçalho
            }
        })
        .then(response => response.json().then(data => ({ status: response.status, body: data })))
        .then(({ status, body }) => {
            if (status === 201) {
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso',
                    text: body.success,
                });

                modal.hide();

                // Recarrega os dados chamando a função de carregamento
                document.getElementById('ordens-container').innerHTML = '';
                resetarCardsInicial();
                fetchContagemStatusOrdens();

            } else {
                // Exibe o erro vindo do backend
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: body.error || 'Erro ao excluir a ordem.',
                });
            }
        })
        .catch((error) => {
            console.error('Erro:', error);
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Ocorreu um erro inesperado. Tente novamente mais tarde.',
            });
        });
    });
}

// Função separada para evitar múltiplos event listeners
async function handleSubmit(event) {
    event.preventDefault(); // Evita o recarregamento da página

    const form = event.target;
    const formData = new FormData(form);

    Swal.fire({
        title: 'Enviando...',
        text: 'Aguarde enquanto processamos sua solicitação.',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        },
    });

    try {
        const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;
        const response = await fetch('api/criar-ordem-estamparia/', {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrfToken,
            },
            body: formData,
        });

        const data = await response.json();

        Swal.close();

        if (response.ok) {
            Swal.fire({
                title: 'Sucesso!',
                text: 'Ordem de Produção criada com sucesso.',
                confirmButtonText: 'OK',
            });

            form.reset();

            //  Remove o foco do elemento ativo antes de fechar o modal
            document.activeElement.blur();

            // Fecha corretamente o modal atual
            const modalPlanejarInstance = bootstrap.Modal.getInstance(document.getElementById('modalEstamparia'));
            if (modalPlanejarInstance) {
                modalPlanejarInstance.hide();
            }

            // Recarrega os cards
            document.getElementById('ordens-container').innerHTML = '';
            resetarCardsInicial();

            // Abre o modal correto
            const modal = new bootstrap.Modal(document.getElementById('modalIniciarAposPlanejar'));
            modal.show();

            // Remove event listeners antigos antes de adicionar novos
            const btnIniciar = document.querySelector('.btn-iniciar-planejar');
            const btnNaoIniciar = document.querySelector('.btn-nao-iniciar-planejar');

            if (btnIniciar) {
                btnIniciar.replaceWith(btnIniciar.cloneNode(true));
                document.querySelector('.btn-iniciar-planejar').addEventListener('click', function () {
                    modal.hide();
                    mostrarModalIniciar(data.ordem_id, 'estamparia');
                });
            }

            if (btnNaoIniciar) {
                btnNaoIniciar.replaceWith(btnNaoIniciar.cloneNode(true));
                document.querySelector('.btn-nao-iniciar-planejar').addEventListener('click', function () {
                    modal.hide();
                });
            }

            fetchContagemStatusOrdens();

        } else {
            Swal.fire({
                title: 'Erro!',
                text: data.error || 'Erro ao criar a Ordem de Produção.',
                confirmButtonText: 'OK',
            });
        }
    } catch (error) {
        Swal.close();
        Swal.fire({
            title: 'Erro inesperado!',
            text: 'Ocorreu um erro ao processar sua solicitação. Tente novamente.',
            confirmButtonText: 'OK',
        });
        console.error('Erro:', error);
    }
}

// Modal para "planejar"
function modalPlanejar() {
    const form = document.getElementById('opEstampariaForm');

    if (!form) {
        console.error("Formulário não encontrado!");
        
        return;
    }

    // Remove qualquer evento de submit duplicado antes de adicionar um novo
    form.removeEventListener('submit', handleSubmit);
    form.addEventListener('submit', handleSubmit);
}

export function resetarCardsInicial(filtros = {}) {
    const container = document.getElementById('ordens-container');
    let isLoading = false; // Flag para evitar chamadas simultâneas

    // Obtém os filtros atualizados
    const filtroDataCarga = document.getElementById('filtro-data-carga');
    const filtroCor = document.getElementById('filtro-cor');
    const filtroConjunto = document.getElementById('filtro-conjunto');
    const filtroDataProgramada = document.getElementById('filtro-data-programada');

    if (!filtroDataCarga.value) {
        filtroDataCarga.value = new Date().toISOString().slice(0, 10);
    }

    const currentFiltros = {
        data_carga: filtroDataCarga.value,
        cor: filtroCor.value,
        conjunto: filtroConjunto.value,
        data_programada: filtroDataProgramada.value,
    };

    // Função para buscar e renderizar ordens sem paginação
    const fetchOrdens = () => {
        if (isLoading) return;
        isLoading = true;

        loadOrdens(container, currentFiltros) // Carrega todas as ordens de uma vez
            .then((data) => {
                if (data.ordens.length === 0) {
                    container.innerHTML = '<p class="text-muted">Nenhuma ordem encontrada.</p>';
                }
            })
            .catch((error) => {
                console.error('Erro ao carregar ordens:', error);
                container.innerHTML = '<p class="text-danger">Erro ao carregar as ordens.</p>';
            })
            .finally(() => {
                isLoading = false;
            });
    };

    // Limpa o container antes de carregar novos resultados e chama a função
    container.innerHTML = '';
    fetchOrdens();
}

function filtro() {
    const form = document.getElementById('filtro-form');

    form.addEventListener('submit', (event) => {
        event.preventDefault(); // Evita comportamento padrão do formulário

        const filtroDataCarga = document.getElementById('filtro-data-carga');
        const filtroCor = document.getElementById('filtro-cor');
        const filtroConjunto = document.getElementById('filtro-conjunto');
        const filtroDataProgramada = document.getElementById('filtro-data-programada');

        // Captura os valores atualizados dos filtros
        const filtros = {
            data_carga: filtroDataCarga.value,
            cor: filtroCor.value,
            conjunto: filtroConjunto.value,
            data_programada: filtroDataProgramada.value,
        };

        // Recarrega os resultados com os novos filtros
        resetarCardsInicial(filtros);

    });
}


// selectTipo.addEventListener("change", async () => {
//     const selectCambao = document.getElementById("cambaoSelecionado");
//     const tipoPintura = selectTipo.value;   

//     selectCambao.disabled = true;

//     // Atualiza o select para indicar carregamento
//     selectCambao.innerHTML = `<option value="">Carregando...</option>`;

//     // Buscar cambões disponíveis da API
//     try {
//         const response = await fetch(`api/cambao-livre/?tipo=${encodeURIComponent(tipoPintura)}`);
//         const data = await response.json();

//         if (data.cambao_livres.length > 0) {

//             selectCambao.disabled = false;

//             selectCambao.innerHTML = `<option value="">Selecione um cambão...</option>`;
//             data.cambao_livres.forEach(cambao => {
//                 selectCambao.innerHTML += `<option value="${cambao.id}">Cambão ${cambao.nome}</option>`;
//             });
//         } else {
            
//             selectCambao.innerHTML = `<option value="">Nenhum cambão disponível</option>`;
//         }
//     } catch (error) {
//         console.error("Erro ao buscar cambões:", error);
//         selectCambao.innerHTML = `<option value="">Erro ao carregar cambões</option>`;
//         Swal.close();
//     }
// });
// Registra o listener apenas uma vez, fora da função abrirModalCambao
const selectTipo = document.getElementById("tipoPintura");
// Função para atualizar os cambões disponíveis - reaproveitando-a para a abertura do modal de criação
async function atualizarCamboesDisponiveis(){
    const selectCambao = document.getElementById("cambaoSelecionado");
    const tipoPintura = selectTipo.value;   

    selectCambao.disabled = true;

    // Atualiza o select para indicar carregamento
    selectCambao.innerHTML = `<option value="">Carregando...</option>`;

    // Buscar cambões disponíveis da API
    try {
        const response = await fetch(`api/cambao-livre/?tipo=${encodeURIComponent(tipoPintura)}`);
        const data = await response.json();

        if (data.cambao_livres.length > 0) {

            selectCambao.disabled = false;

            selectCambao.innerHTML = `<option value="">Selecione um cambão...</option>`;
            data.cambao_livres.forEach(cambao => {
                selectCambao.innerHTML += `<option value="${cambao.id}">Cambão ${cambao.nome}</option>`;
            });
        } else {
            
            selectCambao.innerHTML = `<option value="">Nenhum cambão disponível</option>`;
        }
    } catch (error) {
        console.error("Erro ao buscar cambões:", error);
        selectCambao.innerHTML = `<option value="">Erro ao carregar cambões</option>`;
        Swal.close();
    }
}

if (typeTemplate === 'apontamento') {

    let modalCriarCambao = document.getElementById("modalCriarCambao");
    
    selectTipo.addEventListener("change", async () => atualizarCamboesDisponiveis()); // Atualiza os cambões disponíveis quando o tipo de pintura muda
    modalCriarCambao.addEventListener("show.bs.modal", async() => atualizarCamboesDisponiveis());
}

async function abrirModalCambao() {
    const checkboxes = document.querySelectorAll(".ordem-checkbox:checked");
    const tabelaCambao = document.getElementById("tabelaCambao");
    const corCambao = document.getElementById("corCambao");
    const selectCambao = document.getElementById("cambaoSelecionado");

    if (checkboxes.length === 0) {
        Swal.fire({
            icon: "warning",
            title: "Nenhuma ordem selecionada",
            text: "Selecione pelo menos uma ordem para criar um cambão.",
            confirmButtonText: "OK"
        });
        return;
    }

    let corSelecionada = checkboxes[0].dataset.cor;
    let pecaOrdens = [];
    let quantidades = [];
    let erros = [];

    tabelaCambao.innerHTML = ""; // Limpa a tabela antes de preencher
    selectCambao.innerHTML = `<option value="">Carregando...</option>`; // Carrega cambões

    // const selectTipo = document.getElementById("tipoPintura");

    // selectTipo.addEventListener("change", async () => {
    //     const tipoPintura = selectTipo.value;   

    //     // Buscar cambões disponíveis da API
    //     try {
    //         const response = await fetch(`api/cambao-livre/?tipo=${tipoPintura}`);
    //         const data = await response.json();

    //         if (data.cambao_livres.length > 0) {
    //             selectCambao.innerHTML = `<option value="">Selecione um cambão...</option>`;
    //             data.cambao_livres.forEach(cambao => {
    //                 selectCambao.innerHTML += `<option value="${cambao.id}">Cambão ${cambao.id}</option>`;
    //             });
    //         } else {
    //             selectCambao.innerHTML = `<option value="">Nenhum cambão disponível</option>`;
    //         }
    //     } catch (error) {
    //         console.error("Erro ao buscar cambões:", error);
    //         selectCambao.innerHTML = `<option value="">Erro ao carregar cambões</option>`;
    //         Swal.close();
    //     }
    // });

    checkboxes.forEach(cb => {
        const linha = cb.closest("tr");
        const pecaOrdem = linha.dataset.pecaOrdem;
        const codigoPeca = linha.querySelector("a").textContent;
        const quantidadeInput = linha.querySelector(".qt-produzida");
        const quantidade = parseInt(quantidadeInput.value, 10);

        if (!quantidade || quantidade <= 0) {
            erros.push(`Ordem #${pecaOrdem}: Defina uma quantidade válida.`);
            return;
        }

        pecaOrdens.push(pecaOrdem);
        quantidades.push(quantidade);

        tabelaCambao.innerHTML += `
            <tr>
                <td>#${pecaOrdem}</td>
                <td>${codigoPeca}</td>
                <td>${quantidade}</td>
            </tr>
        `;
    });

    if (erros.length > 0) {
        Swal.fire({
            icon: "warning",
            title: "Erro ao criar Cambão",
            html: erros.join("<br>"),
            confirmButtonText: "OK"
        });
        return;
    }

    corCambao.textContent = corSelecionada;

    document.getElementById("confirmarCriacaoCambao").dataset.cambaoData = JSON.stringify({
        peca_ordens: pecaOrdens,
        quantidade: quantidades,
        cor: corSelecionada
    });

    const operadorSelect = document.getElementById('operadorInicial');

    fetch("api/listar-operadores/")
    .then(response => {
        if (!response.ok) {
            throw new Error("Erro ao buscar operadores");
        }
        return response.json();
    })
    .then(data => {
        operadorSelect.innerHTML = `<option value="" disabled selected>Selecione um operador...</option>`;
        
        if (data.operadores.length === 0) {
            operadorSelect.innerHTML = `<option value="" disabled>Nenhum operador encontrado</option>`;
        } else {
            data.operadores.forEach(operador => {
                operadorSelect.innerHTML += `<option value="${operador.id}">${operador.matricula} - ${operador.nome}</option>`;
            });
            operadorSelect.disabled = false; // Habilita o select após carregar os dados
        }
    })
    .catch(error => {
        console.error("Erro ao carregar operadores:", error);
        operadorSelect.innerHTML = `<option value="" disabled>Erro ao carregar</option>`;
    });

    let modal = new bootstrap.Modal(document.getElementById("modalCriarCambao"));
    modal.show();
}

async function abrirModalProgramacao() {
    const checkboxes = document.querySelectorAll(".ordem-checkbox:checked");
    const tabelaCambao = document.getElementById("tabelaCambao");
    const corCambao = document.getElementById("corCambao");

    if (checkboxes.length === 0) {
        Swal.fire({
            icon: "warning",
            title: "Nenhuma ordem selecionada",
            text: "Selecione pelo menos uma ordem para criar um cambão.",
            confirmButtonText: "OK"
        });
        return;
    }

    let corSelecionada = checkboxes[0].dataset.cor;
    let pecaOrdens = [];
    let quantidades = [];
    let erros = [];

    tabelaCambao.innerHTML = ""; // Limpa a tabela antes de preencher

    checkboxes.forEach(cb => {
        const linha = cb.closest("tr");
        const pecaOrdem = linha.dataset.pecaOrdem;
        const codigoPeca = linha.querySelector("a").textContent;
        const quantidadeInput = linha.querySelector(".qt-produzida");
        const quantidade = parseInt(quantidadeInput.value, 10);

        if (!quantidade || quantidade <= 0) {
            erros.push(`Ordem #${pecaOrdem}: Defina uma quantidade válida.`);
            return;
        }

        pecaOrdens.push(pecaOrdem);
        quantidades.push(quantidade);

        tabelaCambao.innerHTML += `
            <tr>
                <td>#${pecaOrdem}</td>
                <td>${codigoPeca}</td>
                <td>${quantidade}</td>
            </tr>
        `;
    });

    if (erros.length > 0) {
        Swal.fire({
            icon: "warning",
            title: "Erro ao criar Cambão",
            html: erros.join("<br>"),
            confirmButtonText: "OK"
        });
        return;
    }

    corCambao.textContent = corSelecionada;

    document.getElementById("confirmarCriacaoProgramacao").dataset.cambaoData = JSON.stringify({
        peca_ordens: pecaOrdens,
        quantidade: quantidades,
        cor: corSelecionada
    });

    let modal = new bootstrap.Modal(document.getElementById("modalPlanejarPrograma"));
    modal.show();
}

// Função de contador para mostrar tempo decorrido
function iniciarContador(cambaoId, dataCriacao) {
    const contador = document.getElementById(`contador-${cambaoId}`);
    const dataInicial = new Date(dataCriacao); // Converte a data de criação para objeto Date

    function atualizarContador() {
        const agora = new Date();
        const diferenca = Math.floor((agora - dataInicial) / 1000); // Diferença em segundos

        const dias = Math.floor(diferenca / 86400);
        const horas = Math.floor((diferenca % 86400) / 3600);
        const minutos = Math.floor((diferenca % 3600) / 60);
        const segundos = diferenca % 60;

        contador.textContent = `${dias}d ${horas}h ${minutos}m ${segundos}s`;
    }

    // Atualiza o contador a cada segundo
    atualizarContador();
    setInterval(atualizarContador, 1000);
}

// Evento para confirmar a criação do cambão
if (typeTemplate === 'apontamento'){
    document.getElementById("confirmarCriacaoCambao").addEventListener("click", () => {

        const botaoConfirmar = document.getElementById("confirmarCriacaoCambao");
        
        const selectCambao = document.getElementById("cambaoSelecionado");
        const selectTipo = document.getElementById("tipoPintura");
        const selectOperador = document.getElementById("operadorInicial");
        const cambaoId = selectCambao.value;
        const tipoId = selectTipo.value;
        const operadorId = selectOperador.value;
        
        const dadosCambao = JSON.parse(botaoConfirmar.dataset.cambaoData);
        let modal = document.getElementById("modalCriarCambao");
        
        if (!cambaoId) {

            console.log("Alerta: Cambão não selecionado!");
            Swal.fire({
                icon: "warning",
                title: "Seleção obrigatória",
                text: "Por favor, selecione um cambão antes de continuar.",
                confirmButtonText: "OK",
                allowOutsideClick: false
            });
            return;
        } else if (!tipoId) {
            console.log("Alerta: Tipo não selecionado!");
            Swal.fire({
                icon: "warning",
                title: "Seleção obrigatória",
                text: "Por favor, selecione um tipo antes de continuar.",
                confirmButtonText: "OK",
                allowOutsideClick: false
            });
            return;
        } else if (!operadorId) {
            console.log("Alerta: Operador não selecionado!");
            Swal.fire({
                icon: "warning",
                title: "Seleção obrigatória",
                text: "Por favor, selecione um operador antes de continuar.",
                confirmButtonText: "OK",
                allowOutsideClick: false
            });
            return;
        }

        // Adiciona o cambão selecionado ao payload
        dadosCambao.cambao_id = parseInt(cambaoId);
        dadosCambao.tipo = tipoId;
        dadosCambao.operador = operadorId;

        Swal.fire({
            title: 'Carregando...',
            text: 'Aguarde...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        fetch("api/add-pecas-cambao/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                // "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value
            },
            body: JSON.stringify(dadosCambao)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: "success",
                    title: "Cambão Criado",
                    text: "O cambão foi gerado com sucesso.",
                    confirmButtonText: "OK"
                }).then(() => {
                    Swal.close();

                    let modalInstance = bootstrap.Modal.getInstance(modal);
                    if (modalInstance) {
                        modalInstance.hide();
                    };
                    
                    resetarCardsInicial();
                    cambaoProcesso();
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Erro ao Criar Cambão",
                    text: data.error || "Ocorreu um erro ao gerar o cambão.",
                    confirmButtonText: "OK"
                });
            }
        })
        .catch(error => {
            console.error("Erro ao criar cambão:", error);
            Swal.fire({
                icon: "error",
                title: "Erro",
                text: "Ocorreu um erro ao tentar criar o cambão.",
                confirmButtonText: "OK"
            });
        });
    });
}

// Evento para confirmar o planejamento da programação
if (typeTemplate === 'programacao'){
    document.getElementById("confirmarCriacaoProgramacao").addEventListener("click", () => {

        const botaoConfirmar = document.getElementById("confirmarCriacaoProgramacao");
        
        const selectTipo = document.getElementById("tipoPintura");
        const tipoId = selectTipo.value;
        
        const dataPlanejamento = document.getElementById("dataPlanejamento").value;

        const dadosCambao = JSON.parse(botaoConfirmar.dataset.cambaoData);
        let modal = document.getElementById("modalPlanejarPrograma");
        
        if (!tipoId) {
            console.log("Alerta: Tipo não selecionado!");
            Swal.fire({
                icon: "warning",
                title: "Seleção obrigatória",
                text: "Por favor, selecione um tipo antes de continuar.",
                confirmButtonText: "OK",
                allowOutsideClick: false
            });
            return;
        }

        // Adiciona o tipo selecionado ao payload
        dadosCambao.tipo = tipoId;
        dadosCambao.data_planejamento = dataPlanejamento;

        Swal.fire({
            title: 'Carregando...',
            text: 'Aguarde...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        fetch("/pintura/api/add-pecas-programacao/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                // "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value
            },
            body: JSON.stringify(dadosCambao)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: "success",
                    title: "Programação criada",
                    text: "A programação foi gerada com sucesso.",
                    confirmButtonText: "OK"
                }).then(() => {
                    Swal.close();

                    let modalInstance = bootstrap.Modal.getInstance(modal);
                    if (modalInstance) {
                        modalInstance.hide();
                    };

                    resetarCardsInicial();
                    
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Erro ao Criar Programação",
                    text: data.error || "Ocorreu um erro ao gerar a programação.",
                    confirmButtonText: "OK"
                });
            }
        })
        .catch(error => {
            console.error("Erro ao criar programação:", error);
            Swal.fire({
                icon: "error",
                title: "Erro",
                text: "Ocorreu um erro ao tentar criar a programação.",
                confirmButtonText: "OK"
            });
        });
    });
}

function formatarQuantidade(valor) {
    const numero = Number(valor || 0);
    return Number.isInteger(numero) ? `${numero}` : numero.toLocaleString('pt-BR');
}

function renderizarTabelaEdicaoCambao() {
    const tbody = document.getElementById("editarCambaoTabelaBody");

    if (!edicaoCambaoAtual || edicaoCambaoAtual.itens.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted py-4">Nenhum item no cambão.</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = edicaoCambaoAtual.itens.map((item, index) => `
        <tr>
            <td>${item.ordem || ''}</td>
            <td title="${item.peca}">${item.peca}</td>
            <td>${item.data_carga || ''}</td>
            <td>${formatarQuantidade(item.saldo_disponivel)}</td>
            <td>
                <input
                    type="number"
                    class="form-control form-control-sm input-quantidade-cambao"
                    data-index="${index}"
                    min="0.01"
                    step="0.01"
                    value="${item.quantidade_pendurada}"
                >
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-danger btn-remover-item-cambao" data-index="${index}" title="Remover item">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');

    document.querySelectorAll(".input-quantidade-cambao").forEach((input) => {
        input.addEventListener("input", (event) => {
            const index = Number(event.target.dataset.index);
            edicaoCambaoAtual.itens[index].quantidade_pendurada = event.target.value;
        });
    });

    document.querySelectorAll(".btn-remover-item-cambao").forEach((botao) => {
        botao.addEventListener("click", (event) => {
            const index = Number(event.currentTarget.dataset.index);
            edicaoCambaoAtual.itens.splice(index, 1);
            renderizarTabelaEdicaoCambao();
        });
    });
}

function inicializarSelectPesquisaCambao() {
    const $select = $("#pesquisaCambaoItemSelect");
    const $modal = $("#modalPesquisarItemCambao");

    if (!$select.length) {
        return;
    }

    if ($select.hasClass("select2-hidden-accessible")) {
        $select.select2("destroy");
    }

    $select.select2({
        width: "100%",
        placeholder: "Selecione uma peça...",
        allowClear: true,
        dropdownParent: $modal,
        minimumInputLength: 2,
        ajax: {
            delay: 250,
            url: "api/ordens-criadas/",
            dataType: "json",
            data: (params) => ({
                data_carga: document.getElementById("pesquisaCambaoDataCarga")?.value || "",
                type_template: "apontamento",
                cor: edicaoCambaoAtual?.cor || "",
                conjunto: params.term || "",
                "data-programada": "",
            }),
            processResults: (data) => {
                itensDisponiveisCambao = (data.ordens || []).map((item) => ({
                    peca_ordem_id: item.peca_ordem_id,
                    ordem: item.ordem,
                    peca: item.peca_codigo,
                    saldo_disponivel: item.qt_restante,
                    data_carga: item.data_carga,
                }));
                return {
                    results: itensDisponiveisCambao.map((item) => ({
                        id: item.peca_ordem_id,
                        text: `OP ${item.ordem} | ${item.peca} | saldo ${formatarQuantidade(item.saldo_disponivel)} | ${item.data_carga}`,
                        ...item,
                    })),
                };
            },
        },
        language: {
            inputTooShort: () => "Digite ao menos 2 caracteres para buscar",
            noResults: () => "Nenhum item encontrado",
            searching: () => "Buscando...",
        },
    });
}

function abrirModalPesquisaCambao() {
    if (!edicaoCambaoAtual) {
        return;
    }

    document.getElementById("pesquisaCambaoDataCarga").value = "";
    document.getElementById("pesquisaCambaoQuantidade").value = "1";
    document.getElementById("pesquisaCambaoItemSelect").disabled = true;
    itensDisponiveisCambao = [];
    inicializarSelectPesquisaCambao();
    $("#pesquisaCambaoItemSelect").val(null).trigger("change");

    const modal = new bootstrap.Modal(document.getElementById("modalPesquisarItemCambao"));
    modal.show();
}

function adicionarItemPesquisadoCambao() {
    if (!edicaoCambaoAtual) {
        return;
    }

    const quantidadeInput = document.getElementById("pesquisaCambaoQuantidade");
    const quantidade = Number(quantidadeInput.value);
    const itemSelecionado = ($("#pesquisaCambaoItemSelect").select2("data") || [])[0];

    if (!itemSelecionado) {
        Swal.fire({
            icon: "warning",
            title: "Selecione uma peça",
            text: "Escolha uma peça para adicionar ao cambão.",
        });
        return;
    }

    if (!quantidade || quantidade <= 0) {
        Swal.fire({
            icon: "warning",
            title: "Quantidade inválida",
            text: "Informe uma quantidade maior que zero.",
        });
        return;
    }

    const linhaExistente = edicaoCambaoAtual.itens.find((item) => item.peca_ordem_id === itemSelecionado.peca_ordem_id);
    const quantidadeAtualNoCambao = linhaExistente
        ? Number(linhaExistente.quantidade_pendurada || 0)
        : 0;
    const quantidadeMaximaPermitida = Number(itemSelecionado.saldo_disponivel || 0);
    const novaQuantidadeTotal = quantidadeAtualNoCambao + quantidade;

    if (novaQuantidadeTotal > quantidadeMaximaPermitida) {
        const saldoAdicionalDisponivel = Math.max(0, quantidadeMaximaPermitida - quantidadeAtualNoCambao);
        Swal.fire({
            icon: "warning",
            title: "Quantidade indisponível",
            text: `Esse item possui apenas ${formatarQuantidade(saldoAdicionalDisponivel)} unidade(s) disponível(is) fora de processo e pendente para adicionar ao cambão.`,
        });
        return;
    }

    if (linhaExistente) {
        linhaExistente.quantidade_pendurada = novaQuantidadeTotal;
    } else {
        edicaoCambaoAtual.itens.push({
            id: null,
            peca_ordem_id: itemSelecionado.peca_ordem_id,
            ordem: itemSelecionado.ordem,
            peca: itemSelecionado.peca,
            data_carga: itemSelecionado.data_carga,
            quantidade_pendurada: quantidade,
            saldo_disponivel: itemSelecionado.saldo_disponivel,
        });
    }

    renderizarTabelaEdicaoCambao();

    const modalInstance = bootstrap.Modal.getInstance(document.getElementById("modalPesquisarItemCambao"));
    if (modalInstance) {
        modalInstance.hide();
    }
}

async function abrirModalEditarCambao(cambaoId) {
    if (carregandoEdicaoCambao) {
        return;
    }

    const cambao = camboesEmProcessoMap.get(Number(cambaoId));
    if (!cambao) {
        Swal.fire({
            icon: "error",
            title: "Cambão não encontrado",
            text: "Não foi possível carregar os dados do cambão selecionado.",
        });
        return;
    }

    carregandoEdicaoCambao = true;
    Swal.fire({
        title: 'Carregando...',
        text: `Preparando a edição do cambão #${cambao.nome}.`,
        allowOutsideClick: false,
        allowEscapeKey: false,
        didOpen: () => Swal.showLoading(),
    });

    edicaoCambaoAtual = {
        id: cambao.id,
        nome: cambao.nome,
        cor: cambao.cor,
        tipo: cambao.tipo,
        itens: cambao.pecas.map((peca) => ({
            id: peca.id,
            peca_ordem_id: peca.peca_ordem_id,
            ordem: peca.ordem,
            peca: peca.peca,
            data_carga: new Intl.DateTimeFormat('pt-BR').format(new Date(`${peca.data_carga}T00:00:00`)),
            quantidade_pendurada: peca.quantidade_pendurada,
            saldo_disponivel: Number(peca.quantidade_pendurada || 0),
        })),
    };

    document.getElementById("editarCambaoResumo").textContent = `Cambão #${cambao.nome} • ${cambao.cor} • ${cambao.tipo}`;

    renderizarTabelaEdicaoCambao();
    Swal.close();

    const modal = new bootstrap.Modal(document.getElementById("modalEditarCambao"));
    modal.show();
    carregandoEdicaoCambao = false;
}

async function salvarEdicaoCambao() {
    if (!edicaoCambaoAtual) {
        return;
    }

    const itens = edicaoCambaoAtual.itens.map((item) => ({
        id: item.id,
        peca_ordem_id: item.peca_ordem_id,
        quantidade: item.quantidade_pendurada,
    }));

    Swal.fire({
        title: 'Salvando...',
        text: 'Atualizando cambão...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading(),
    });

    try {
        const response = await fetch("api/editar-cambao/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                cambao_id: edicaoCambaoAtual.id,
                itens,
            }),
        });

        const data = await response.json();
        if (!response.ok || !data.success) {
            throw new Error(data.error || "Não foi possível salvar as alterações.");
        }

        Swal.fire({
            icon: "success",
            title: "Cambão atualizado",
            text: data.message || "As alterações foram salvas com sucesso.",
        });

        const modalInstance = bootstrap.Modal.getInstance(document.getElementById("modalEditarCambao"));
        if (modalInstance) {
            modalInstance.hide();
        }

        cambaoProcesso();
        resetarCardsInicial();
    } catch (error) {
        Swal.fire({
            icon: "error",
            title: "Erro ao salvar",
            text: error.message,
        });
    }
}

document.getElementById("btnSalvarEdicaoCambao")?.addEventListener("click", salvarEdicaoCambao);
document.getElementById("btnAbrirPesquisaCambao")?.addEventListener("click", abrirModalPesquisaCambao);
document.getElementById("btnSalvarPesquisaCambao")?.addEventListener("click", adicionarItemPesquisadoCambao);
document.getElementById("pesquisaCambaoDataCarga")?.addEventListener("change", (event) => {
    const select = document.getElementById("pesquisaCambaoItemSelect");
    const possuiData = !!event.target.value;
    select.disabled = !possuiData;
    $("#pesquisaCambaoItemSelect").val(null).trigger("change");
});

export async function cambaoProcesso() {
    const cambaoContainer = document.getElementById("cambao-container");
    // cambaoContainer.innerHTML = `
    // <div class="spinner-border text-dark" role="status">
    //     <span class="sr-only">Loading...</span>
    // </div>`;
    
    try {
        const response = await fetch("api/cambao-processo/");
        const data = await response.json();
        camboesEmProcessoMap = new Map((data.cambao_em_processo || []).map((cambao) => [Number(cambao.id), cambao]));
        cambaoContainer.innerHTML = ""; // Limpa antes de adicionar os novos

        if (data.cambao_em_processo.length === 0) {
            cambaoContainer.innerHTML = '<p class="text-muted text-center">Nenhum cambão em processo.</p>';
            return;
        }

        const colorMap = {
            "Vermelho": "#FF4D4D",
            "Azul": "#4D79FF",
            "Verde": "#4CAF50",
            "Amarelo": "#FFC107",
            "Laranja": "#FF9800",
            "Roxo": "#9C27B0",
            "Cinza": "#6C757D",
            "Preto": "#212529",
            "Branco": "#FFFFFF",
            "Marrom": "#795548"
        };

        const coresAgrupadas = {}; // Objeto para agrupar os cambões por cor

        // Agrupa os cambões por cor
        data.cambao_em_processo.forEach(cambao => {
            if (!coresAgrupadas[cambao.cor]) {
                coresAgrupadas[cambao.cor] = [];
            }
            coresAgrupadas[cambao.cor].push(cambao);
        });

        const maxLength = 22; // Número máximo de caracteres a exibir

        // Gera as colunas para cada cor
        Object.entries(coresAgrupadas).forEach(([cor, camboes]) => {
            const corHex = colorMap[cor] || "#808080"; // Se não encontrar, usa cinza padrão
            const colDiv = document.createElement("div");
            colDiv.classList.add("col-md-4");

            colDiv.innerHTML = `
                <div class="card shadow-sm position-relative">
                    <div class="card-header text-white text-center" style="background-color: ${corHex};">
                        <h5>${cor}</h5>
                    </div>
                    <div class="card-body p-2">
                        ${camboes.map(cambao => `
                            <div class="border rounded p-2 mb-2 cambao-card ${cambao.cambao_status === 'interrompido' ? 'border-warning' : ''}">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>Cambão #${cambao.nome}</strong>
                                        ${cambao.cambao_status === 'interrompido' ? '<span class="badge bg-warning text-dark ms-2"><i class="fas fa-pause-circle"></i> INTERROMPIDO</span>' : ''}
                                    </div>
                                    <span class="badge ${cambao.tipo === 'PÓ' ? 'bg-primary' : 'bg-secondary'}">${cambao.tipo}</span>
                                </div>
                                <span class="badge bg-dark text-light px-2 py-1 my-2" 
                                      id="contador-cambao-${cambao.id}" 
                                      style="font-size: 0.85rem;">
                                    Carregando...
                                </span>
                                <ul class="list-unstyled mt-2">
                                    ${cambao.pecas.map(peca => `
                                        <li class="d-flex justify-content-between cambaoInformacoes">
                                            <span>Peça: 
                                                <strong title="${peca.peca}">
                                                    ${peca.peca.length > maxLength ? peca.peca.substring(0, maxLength) + "..." : peca.peca}
                                                </strong>
                                            </span> 
                                            <span>Data Carga: <strong>${new Intl.DateTimeFormat('pt-BR').format(new Date(peca.data_carga+"T00:00:00"))}</strong></span>
                                            <span>Qtd: <strong>${peca.quantidade_pendurada}</strong></span>
                                        </li>
                                        <li class="d-none justify-content-between visualizar-conjuntos" >
                                            <span>Peça: 
                                                <strong title="${peca.peca}">
                                                    ${peca.peca}
                                                </strong>
                                            </span> 
                                        </li>
                                    `).join('')}
                                </ul>
                                <div class="d-flex justify-content-between align-items-center mt-2 gap-2">
                                    <small class="text-muted">Início: ${new Date(cambao.data_pendura).toLocaleString()}</small>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <button id="visualizarConjuntosButton-${cambao.id}" class="btn btn-outline-secondary" title="Visualizar conjuntos completos">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-outline-primary btn-editar-cambao" data-cambao-id="${cambao.id}" title="Editar peças e quantidades">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        ${cambao.cambao_status === 'interrompido' 
                                            ? `<button class="btn btn-outline-info btn-retornar" data-cambao-id="${cambao.id}" title="Retornar cambão ao processo">
                                                <i class="fas fa-play"></i>
                                            </button>`
                                            : `<button class="btn btn-outline-warning btn-interromper" data-cambao-id="${cambao.id}" title="Interromper cambão">
                                                <i class="fas fa-pause"></i>
                                            </button>`
                                        }
                                        <button class="btn btn-outline-danger btn-finalizar" data-cambao-id="${cambao.id}" title="Finalizar cambão">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
            cambaoContainer.appendChild(colDiv);

            // Iniciar contador para cada cambão
            camboes.forEach(cambao => {
                iniciarContador(`cambao-${cambao.id}`, cambao.data_pendura);
            });
        });

        // Modificar visualização para ver nomes de conjuntos completos
        document.querySelectorAll('[id^="visualizarConjuntosButton-"]').forEach(function(botao) {
            botao.addEventListener('click', function() {
                // converte `this` para jQuery para usar jQuery em volta dele
                const $botao = $(this);

                // encontra o elemento .btn-visualizar-conjuntos mais próximo dentro do container comum
                $botao.closest('.cambao-card').find('.visualizar-conjuntos').toggleClass('d-none');

                // faz o mesmo para .cambaoInformacoes
                $botao.closest('.cambao-card').find('.cambaoInformacoes').toggleClass('d-none');
            });
        });

        // Evento de clique para abrir o modal de finalização
        document.querySelectorAll(".btn-editar-cambao").forEach((botao) => {
            botao.addEventListener("click", function () {
                abrirModalEditarCambao(this.dataset.cambaoId);
            });
        });

        document.querySelectorAll(".btn-finalizar").forEach(botao => {
            botao.addEventListener("click", function () {
                const cambaoId = this.dataset.cambaoId;
                document.getElementById("confirmarEncerramentoCambao").dataset.cambaoId = cambaoId;

                const operadorSelect = document.getElementById("operadorSelect");
                operadorSelect.disabled = true; // Bloqueia o select antes de carregar
                operadorSelect.innerHTML = `<option value="" disabled selected>Carregando operadores...</option>`; 

                // Buscar operadores disponíveis para o select
                fetch("api/listar-operadores/")
                    .then(response => {
                        if (!response.ok) {
                            throw new Error("Erro ao buscar operadores");
                        }
                        return response.json();
                    })
                    .then(data => {
                        operadorSelect.innerHTML = `<option value="" disabled selected>Selecione um operador...</option>`;
                        
                        if (data.operadores.length === 0) {
                            operadorSelect.innerHTML = `<option value="" disabled>Nenhum operador encontrado</option>`;
                        } else {
                            data.operadores.forEach(operador => {
                                operadorSelect.innerHTML += `<option value="${operador.id}">${operador.matricula} - ${operador.nome}</option>`;
                            });
                            operadorSelect.disabled = false; // Habilita o select após carregar os dados
                        }
                    })
                    .catch(error => {
                        console.error("Erro ao carregar operadores:", error);
                        operadorSelect.innerHTML = `<option value="" disabled>Erro ao carregar</option>`;
                    });

                // Exibe o modal
                let modal = new bootstrap.Modal(document.getElementById("modalFinalizarCambao"));
                modal.show();
            });
        });

        // Evento de clique para abrir o modal de interrupção
        document.querySelectorAll(".btn-interromper").forEach(botao => {
            botao.addEventListener("click", function () {
                const cambaoId = this.dataset.cambaoId;
                document.getElementById("confirmarInterrupcaoCambao").dataset.cambaoId = cambaoId;

                // Exibe o modal de interrupção
                let modal = new bootstrap.Modal(document.getElementById("modalInterromperCambao"));
                modal.show();
            });
        });

        // Evento de clique para retornar cambão interrompido
        document.querySelectorAll(".btn-retornar").forEach(botao => {
            botao.addEventListener("click", function () {
                const cambaoId = this.dataset.cambaoId;
                
                Swal.fire({
                    title: 'Confirmar retorno?',
                    text: 'Deseja retornar este cambão ao processo?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Sim, retornar',
                    cancelButtonText: 'Cancelar',
                    confirmButtonColor: '#17a2b8'
                }).then((result) => {
                    if (result.isConfirmed) {
                        retornarCambao(cambaoId);
                    }
                });
            });
        });


    } catch (error) {
        console.error("Erro ao buscar cambões:", error);
    }
}

// Evento de clique para confirmar a finalização
document.getElementById("confirmarEncerramentoCambao").removeEventListener("click", finalizarCambao);
document.getElementById("confirmarEncerramentoCambao").addEventListener("click", finalizarCambao);

function finalizarCambao() {
    let modal = document.getElementById("modalFinalizarCambao");
    let modalInstance = bootstrap.Modal.getInstance(modal);

    const cambaoId = this.dataset.cambaoId;
    const operadorId = document.getElementById("operadorSelect").value;

    if (!operadorId) {
        Swal.fire({
            icon: "warning",
            title: "Operador não selecionado",
            text: "Por favor, selecione um operador antes de finalizar o cambão.",
            confirmButtonText: "OK"
        });
        return;
    }

    Swal.fire({
        title: 'Carregando...',
        text: 'Finalizando cambão...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch("api/finalizar-cambao/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            // "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value
        },
        body: JSON.stringify({ cambao_id: cambaoId, operador: operadorId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: "success",
                title: "Cambão Finalizado",
                text: "O cambão foi encerrado com sucesso.",
                confirmButtonText: "OK"
            }).then(() => {
                if (modalInstance) {
                    modalInstance.hide(); // Fecha corretamente o modal
                }
                cambaoProcesso();
            });
        } else {
            Swal.fire({
                icon: "error",
                title: "Erro ao Finalizar",
                text: data.error || "Ocorreu um erro ao finalizar o cambão.",
                confirmButtonText: "OK"
            });
        }
    })
    .catch(error => {
        console.error("Erro ao finalizar cambão:", error);
        Swal.fire({
            icon: "error",
            title: "Erro",
            text: "Ocorreu um erro ao tentar finalizar o cambão.",
            confirmButtonText: "OK"
        });
    });
}

// Evento de clique para confirmar a interrupção
document.getElementById("confirmarInterrupcaoCambao").removeEventListener("click", interromperCambao);
document.getElementById("confirmarInterrupcaoCambao").addEventListener("click", interromperCambao);

function interromperCambao() {
    let modal = document.getElementById("modalInterromperCambao");
    let modalInstance = bootstrap.Modal.getInstance(modal);

    const cambaoId = this.dataset.cambaoId;
    const motivoInterrupcao = document.getElementById("motivoInterrupcao").value;

    if (!motivoInterrupcao || motivoInterrupcao.trim() === "") {
        Swal.fire({
            icon: "warning",
            title: "Motivo não informado",
            text: "Por favor, informe o motivo da interrupção.",
            confirmButtonText: "OK"
        });
        return;
    }

    Swal.fire({
        title: 'Carregando...',
        text: 'Interrompendo cambão...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch("api/interromper-cambao/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ 
            cambao_id: cambaoId, 
            motivo: motivoInterrupcao 
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: "success",
                title: "Cambão Interrompido",
                text: "O cambão foi interrompido com sucesso.",
                confirmButtonText: "OK"
            }).then(() => {
                modalInstance.hide();
                document.getElementById("motivoInterrupcao").value = ""; // Limpa o campo
                cambaoProcesso(); // Recarrega os cambões
                resetarCardsInicial(); // Atualiza os cards
            });
        } else {
            Swal.fire({
                icon: "error",
                title: "Erro ao Interromper",
                text: data.error || "Ocorreu um erro ao interromper o cambão.",
                confirmButtonText: "OK"
            });
        }
    })
    .catch(error => {
        console.error("Erro ao interromper cambão:", error);
        Swal.fire({
            icon: "error",
            title: "Erro",
            text: "Ocorreu um erro ao tentar interromper o cambão.",
            confirmButtonText: "OK"
        });
    });
}

function retornarCambao(cambaoId) {
    Swal.fire({
        title: 'Carregando...',
        text: 'Retornando cambão ao processo...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch("api/retornar-cambao/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ 
            cambao_id: cambaoId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: "success",
                title: "Cambão Retornado",
                text: "O cambão retornou ao processo com sucesso.",
                confirmButtonText: "OK"
            }).then(() => {
                cambaoProcesso(); // Recarrega os cambões
                resetarCardsInicial(); // Atualiza os cards
            });
        } else {
            Swal.fire({
                icon: "error",
                title: "Erro ao Retornar",
                text: data.error || "Ocorreu um erro ao retornar o cambão.",
                confirmButtonText: "OK"
            });
        }
    })
    .catch(error => {
        console.error("Erro ao retornar cambão:", error);
        Swal.fire({
            icon: "error",
            title: "Erro",
            text: "Ocorreu um erro ao tentar retornar o cambão.",
            confirmButtonText: "OK"
        });
    });
}

let _carregarCoresAbortController = null;

function carregarCores(dataCarga) {
    const filtroCor = document.getElementById('filtro-cor');
    if (!filtroCor) return;

    // Cancela requisição anterior se ainda estiver em andamento
    if (_carregarCoresAbortController) {
        _carregarCoresAbortController.abort();
    }
    _carregarCoresAbortController = new AbortController();

    filtroCor.disabled = true;
    filtroCor.innerHTML = `<option value="">Carregando...</option>`;

    fetch(`/pintura/api/cores-carga/?data_carga=${encodeURIComponent(dataCarga)}`, {
        signal: _carregarCoresAbortController.signal,
    })
        .then(response => {
            if (!response.ok) throw new Error("Erro ao buscar cores da carga.");
            return response.json();
        })
        .then(data => {
            filtroCor.innerHTML = `<option value="">------</option>`;

            const cores = (data.cores || [])
                .filter(cor => cor !== null && cor !== undefined && String(cor).trim() !== '')
                .sort();

            cores.forEach(cor => {
                const option = document.createElement('option');
                option.value = cor;
                option.textContent = cor;
                filtroCor.appendChild(option);
            });

            filtroCor.disabled = false;
        })
        .catch(error => {
            if (error.name === 'AbortError') return; // requisição cancelada intencionalmente
            console.error("Erro no carregamento das cores:", error);
            filtroCor.innerHTML = `<option value="">------</option>`;
            filtroCor.disabled = false;
        });
}

// Evento para carregar cores ao mudar a data de carga
function coresCarga() {
    const inputData = document.getElementById('filtro-data-carga');
    if (!inputData) return;
    inputData.addEventListener('change', (event) => {
        const dataCarga = event.target.value;
        if (dataCarga) {
            carregarCores(dataCarga);
        } else {
            const filtroCor = document.getElementById('filtro-cor');
            if (filtroCor) {
                filtroCor.innerHTML = `<option value="">------</option>`;
                filtroCor.disabled = true;
            }
        }
    });
}

function atualizarAndamentoCarga(dataCarga) {

    const percentualDisplay = document.getElementById("percentual-carga");

    percentualDisplay.innerHTML = `
    <div class="spinner-border text-dark" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;

    fetch(`api/andamento-carga/?data_carga=${encodeURIComponent(dataCarga)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro ao buscar andamento da carga.");
            }
            return response.json();
        })
        .then(data => {
            const percentual = data.percentual_concluido || 0; // Se não houver dado, assume 0%

            // Adiciona efeito de transição suave ao atualizar o valor
            percentualDisplay.style.transition = "0.5s ease-in-out";
            percentualDisplay.textContent = `${percentual.toFixed(1)}%`; // Exibe 1 casa decimal
        })
        .catch(error => console.error("Erro no carregamento do andamento da carga:", error));
}

if (typeTemplate === 'apontamento') {
    // Evento de mudança no select para atualizar automaticamente
    document.getElementById("filtro-data-carga").addEventListener("change", function () {
        atualizarAndamentoCarga(this.value);
    });
}

// Evento no botão 🔄 para atualização manual
const btnRefresh = document.getElementById("refresh-status-carga");

if (btnRefresh) {
  btnRefresh.addEventListener("click", function () {
    const dataInput = document.getElementById("filtro-data-carga");
    const dataCarga = dataInput ? dataInput.value : "";

    if (dataCarga) {
      atualizarAndamentoCarga(dataCarga);
    }
  });
}

function atualizarUltimasCargas() {
    const listaCargas = document.getElementById("ultimas-pecas-list");

    listaCargas.innerHTML = `
    <div class="spinner-border text-dark" role="status">
        <span class="sr-only">Loading...</span>
    </div>`;

    fetch("/pintura/api/andamento-ultimas-cargas/")
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro ao buscar andamento das últimas cargas.");
            }
            return response.json();
        })
        .then(data => {
            listaCargas.innerHTML = ""; // Limpa antes de adicionar os novos

            if (data.andamento_cargas.length === 0) {
                listaCargas.innerHTML = `<li class="list-group-item text-muted text-center">Nenhuma carga recente.</li>`;
                return;
            }

            data.andamento_cargas.forEach(carga => {
                const li = document.createElement("li");
                li.classList.add("list-group-item", "d-flex", "justify-content-between", "align-items-center");

                // Criação de uma barra de progresso
                li.innerHTML = `
                <div class="d-flex justify-content-between align-items-center w-100">
                    <span>${carga.data_carga}</span>
                    <div class="progress w-50 position-relative">
                        <div class="progress-bar ${carga.percentual_concluido === 100 ? 'bg-success' : 'bg-warning'}" 
                            role="progressbar" 
                            style="width: ${carga.percentual_concluido}%;"
                            aria-valuenow="${carga.percentual_concluido}" 
                            aria-valuemin="0" 
                            aria-valuemax="100">
                        </div>
                        <span class="position-absolute w-100 text-center fw-bold"
                            style="top: 50%; transform: translateY(-50%); color: black;">
                            ${carga.percentual_concluido}%
                        </span>
                    </div>
                </div>
                `;

                listaCargas.appendChild(li);
            });
        })
        .catch(error => console.error("Erro ao carregar andamento das últimas cargas:", error));
}

// Evento no botão 🔄 para atualização manual
const btnRefreshPecas = document.getElementById("refresh-pecas");

if (btnRefreshPecas) {
  btnRefreshPecas.addEventListener("click", atualizarUltimasCargas);
}

// Chama a função ao carregar a página
document.addEventListener('DOMContentLoaded', () => {

    resetarCardsInicial();
    
    if (typeTemplate === 'apontamento') {

        cambaoProcesso();
        filtro();
        atualizarUltimasCargas();

        const botaoCriarCambao = document.getElementById("btn-criar-cambao");
        botaoCriarCambao.addEventListener("click", () => abrirModalCambao());
    }
    
    if (typeTemplate === 'programacao') {
        filtro();
        const botaoCriarPrograma = document.getElementById("btn-criar-programacao");
        botaoCriarPrograma.addEventListener("click", () => abrirModalProgramacao());
    }
    
    coresCarga();
    
});

function pegarCodigoPeca(peca){
    if (peca.includes("-")) {
        // Se a peça contém um hífen, divide a string e retorna a parte antes do hífen
        const partes = peca.split("-");
        return partes[0].trim(); // Retorna a parte antes do hífen
    }
    return peca; // Se não houver hífen, retorna a peça completa
}
